<?php
include("connect.php");

$sql1 = "SELECT * FROM client";
$exe1 = $bdd->query($sql1);
$recup1 = $exe1->fetchAll();

$sql2 = "SELECT * FROM produit";
$exe2 = $bdd->query($sql2);
$recup2 = $exe2->fetchAll();

if(isset($_POST["valider"])){
    $datecmd = $_POST["datecmd"];
    $etat = $_POST["etat"];
    $idcli = $_POST["client"];
    
    $sql3 = $bdd->prepare("INSERT INTO commande (datecmd, etat, montant, idcli) VALUES(?,?,0,?)");
    $exe3 = $sql3->execute([$datecmd, $etat, $idcli]);
    
    if($exe3){
        $idcmd = $bdd->lastInsertId();
        $total = 0;
        
        $produits = $_POST["produits"];
        $quantites = $_POST["quantites"];
        
        for($i = 0; $i < count($produits); $i++){
            if($produits[$i] != "" && $quantites[$i] > 0){
                $idprod = $produits[$i];
                $quantite = $quantites[$i];
                
                $sql_prod = $bdd->prepare("SELECT prix FROM produit WHERE idprod = ?");
                $sql_prod->execute([$idprod]);
                $produit = $sql_prod->fetch();
                $prix_unitaire = $produit['prix'];
                
                $sql4 = $bdd->prepare("INSERT INTO ligne_commande (idcmd, idprod, quantite, prix_unitaire) VALUES(?,?,?,?)");
                $sql4->execute([$idcmd, $idprod, $quantite, $prix_unitaire]);
                
                $total += $prix_unitaire * $quantite;
            }
        }
        
        $sql5 = $bdd->prepare("UPDATE commande SET montant = ? WHERE idcmd = ?");
        $sql5->execute([$total, $idcmd]);
        
        echo "<script>alert('Enregistrement réussi')</script>";
        header("refresh: 0.5 url=listecommande.php");
    }else{
        echo "<script>alert('Echec enregistrement')</script>";
        header("refresh: 0.5 url=addcommande.php");
    }
}
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="utf-8">
    <title>Electro - Ajouter une Commande</title>
    <meta content="width=device-width, initial-scale=1.0" name="viewport">

    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Open+Sans:wght@400;500;600;700&family=Roboto:wght@400;500;700&display=swap" rel="stylesheet">

    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.15.4/css/all.css" />
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.4.1/font/bootstrap-icons.css" rel="stylesheet">

    <link href="lib/animate/animate.min.css" rel="stylesheet">
    <link href="lib/owlcarousel/assets/owl.carousel.min.css" rel="stylesheet">

    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="css/style.css" rel="stylesheet">
    
    <style>
        .produit-row {
            margin-bottom: 10px;
            padding: 10px;
            border: 1px solid #dee2e6;
            border-radius: 5px;
        }
        
        .btn-add-produit {
            margin-top: 10px;
            margin-bottom: 20px;
        }
    </style>
</head>

<body>
    <div id="spinner" class="show bg-white position-fixed translate-middle w-100 vh-100 top-50 start-50 d-flex align-items-center justify-content-center">
        <div class="spinner-border text-primary" style="width: 3rem; height: 3rem;" role="status">
            <span class="sr-only">Loading...</span>
        </div>
    </div>

    <div class="container-fluid px-5 d-none border-bottom d-lg-block">
        <div class="row gx-0 align-items-center">
            <div class="col-lg-4 text-center text-lg-start mb-lg-0">
                <div class="d-inline-flex align-items-center" style="height: 45px;">
                    <a href="#" class="text-muted me-2"></a><small>  </small>
                    <a href="#" class="text-muted mx-2"></a><small> </small>
                    <a href="#" class="text-muted ms-2"></a>
                </div>
            </div>
            <div class="col-lg-4 text-center d-flex align-items-center justify-content-center">
                <small class="text-dark"></small>
                <a href="#" class="text-muted"></a>
            </div>
            <div class="col-lg-4 text-center text-lg-end">
                <div class="d-inline-flex align-items-center" style="height: 45px;">
                    <a href="#" class="text-muted"></a>
                </div>
            </div>
        </div>
    </div>

    <div class="container-fluid nav-bar p-0">
        <div class="row gx-0 bg-primary px-5 align-items-center">
            <div class="col-12">
                <nav class="navbar navbar-expand-lg navbar-light bg-primary">
                    <a href="#" class="navbar-brand d-block d-lg-none">
                        <h1 class="display-5 text-secondary m-0"><i class="fas fa-shopping-bag text-white me-2"></i>Electro</h1>
                    </a>
                    <button class="navbar-toggler ms-auto" type="button" data-bs-toggle="collapse" data-bs-target="#navbarCollapse">
                        <span class="fa fa-bars fa-1x"></span>
                    </button>
                    <div class="collapse navbar-collapse" id="navbarCollapse">
                        <div class="navbar-nav ms-auto py-0">
                            <a href="sessionadmin.php" class="nav-item nav-link">Acceuil</a>
                            <a href="listecat.php" class="nav-item nav-link">Catégorie</a>
                            <a href="listeprod.php" class="nav-item nav-link">Produit</a>
                            <a href="listeclient.php" class="nav-item nav-link">Client</a>
                            <a href="listecommande.php" class="nav-item nav-link">Commande</a>
                        </div>
                        <a href="#"></a>
                    </div>
                </nav>
            </div>
        </div>
    </div>

    <div class="container-fluid page-header py-5">
        <h1 class="text-center text-white display-6 wow fadeInUp" data-wow-delay="0.1s">Gestion des Commandes</h1>
    </div>

    <div class="container-fluid contact py-5">
        <div class="container py-5">
            <div class="p-5 bg-light rounded">
                <div class="text-center mx-auto wow fadeInUp mb-5" data-wow-delay="0.1s" style="max-width: 800px;">
                    <h4 class="text-primary border-bottom border-primary border-2 d-inline-block pb-2">Formulaire d'Ajout Commande</h4>
                    <p>Renseignez les informations de la commande.</p>
                </div>

                <form action="addcommande.php" method="POST" class="wow fadeInUp" data-wow-delay="0.3s">
                    <div class="row g-4">
                        <div class="col-lg-6">
                            <div class="form-floating">
                                <input type="date" class="form-control" id="datecmd" name="datecmd" value="<?= date('Y-m-d') ?>" required>
                                <label for="datecmd">Date de commande</label>
                            </div>
                        </div>
                        <div class="col-lg-6">
                            <div class="form-floating">
                                <select class="form-select" id="etat" name="etat" required>
                                    <option selected disabled>Choisir un état</option>
                                    <option value="En cours">En cours</option>
                                    <option value="Livrée">Livrée</option>
                                    <option value="Annulée">Annulée</option>
                                </select>
                                <label for="etat">État</label>
                            </div>
                        </div>
                        <div class="col-12">
                            <div class="form-floating">
                                <select class="form-select" id="client" name="client" required>
                                    <option selected disabled>Choisir un client</option>
                                    <?php foreach ($recup1 as $client) { ?>
                                        <option value="<?= $client['idcli'] ?>"><?= $client['nom'] ?> <?= $client['prenom'] ?></option>
                                    <?php } ?>
                                </select>
                                <label for="client">Client</label>
                            </div>
                        </div>
                        
                        <div class="col-12">
                            <h5>Produits commandés</h5>
                            <div id="produits-container">
                                <div class="produit-row">
                                    <div class="row">
                                        <div class="col-md-6">
                                            <select class="form-select" name="produits[]" required>
                                                <option value="">Choisir un produit</option>
                                                <?php foreach ($recup2 as $prod) { ?>
                                                    <option value="<?= $prod['idprod'] ?>"><?= $prod['designation'] ?> - <?= $prod['prix'] ?> FCFA (Stock: <?= $prod['stock'] ?>)</option>
                                                <?php } ?>
                                            </select>
                                        </div>
                                        <div class="col-md-4">
                                            <input type="number" class="form-control" name="quantites[]" placeholder="Quantité" min="1" required>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <button type="button" class="btn btn-success btn-add-produit" onclick="ajouterProduit()">
                                <i class="fas fa-plus"></i> Ajouter un autre produit
                            </button>
                        </div>
                        
                        <div class="col-12">
                            <button type="submit" class="btn btn-primary w-100 py-3" name="valider">Ajouter la commande</button>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <div class="container-fluid footer py-5 wow fadeIn" data-wow-delay="0.2s">
        <div class="container py-5">
            <div class="row g-5">
                <div class="col-md-6 col-lg-6 col-xl-3">
                    <div class="footer-item d-flex flex-column">
                        <div class="footer-item">
                            <h4 class="text-primary mb-4">Newsletter</h4>
                            <p class="mb-3">Dolor amet sit justo amet elitr clita ipsum elitr est.Lorem ipsum dolor sit amet, consectetur adipiscing elit consectetur adipiscing elit.</p>
                            <div class="position-relative mx-auto rounded-pill">
                                <input class="form-control rounded-pill w-100 py-3 ps-4 pe-5" type="text" placeholder="Enter your email">
                                <button type="button" class="btn btn-primary rounded-pill position-absolute top-0 end-0 py-2 mt-2 me-2">SignUp</button>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-md-6 col-lg-6 col-xl-3">
                    <div class="footer-item d-flex flex-column">
                        <h4 class="text-primary mb-4">Customer Service</h4>
                        <a href="#" class=""><i class="fas fa-angle-right me-2"></i> Contact Us</a>
                        <a href="#" class=""><i class="fas fa-angle-right me-2"></i> Returns</a>
                        <a href="#" class=""><i class="fas fa-angle-right me-2"></i> Order History</a>
                        <a href="#" class=""><i class="fas fa-angle-right me-2"></i> Site Map</a>
                        <a href="#" class=""><i class="fas fa-angle-right me-2"></i> Testimonials</a>
                        <a href="#" class=""><i class="fas fa-angle-right me-2"></i> My Account</a>
                        <a href="#" class=""><i class="fas fa-angle-right me-2"></i> Unsubscribe Notification</a>
                    </div>
                </div>
                <div class="col-md-6 col-lg-6 col-xl-3">
                    <div class="footer-item d-flex flex-column">
                        <h4 class="text-primary mb-4">Information</h4>
                        <a href="#" class=""><i class="fas fa-angle-right me-2"></i> About Us</a>
                        <a href="#" class=""><i class="fas fa-angle-right me-2"></i> Delivery infomation</a>
                        <a href="#" class=""><i class="fas fa-angle-right me-2"></i> Privacy Policy</a>
                        <a href="#" class=""><i class="fas fa-angle-right me-2"></i> Terms & Conditions</a>
                        <a href="#" class=""><i class="fas fa-angle-right me-2"></i> Warranty</a>
                        <a href="#" class=""><i class="fas fa-angle-right me-2"></i> FAQ</a>
                        <a href="#" class=""><i class="fas fa-angle-right me-2"></i> Seller Login</a>
                    </div>
                </div>
                <div class="col-md-6 col-lg-6 col-xl-3">
                    <div class="footer-item d-flex flex-column">
                        <h4 class="text-primary mb-4">Extras</h4>
                        <a href="#" class=""><i class="fas fa-angle-right me-2"></i> Brands</a>
                        <a href="#" class=""><i class="fas fa-angle-right me-2"></i> Gift Vouchers</a>
                        <a href="#" class=""><i class="fas fa-angle-right me-2"></i> Affiliates</a>
                        <a href="#" class=""><i class="fas fa-angle-right me-2"></i> Wishlist</a>
                        <a href="#" class=""><i class="fas fa-angle-right me-2"></i> Order History</a>
                        <a href="#" class=""><i class="fas fa-angle-right me-2"></i> Track Your Order</a>
                        <a href="#" class=""><i class="fas fa-angle-right me-2"></i> Track Your Order</a>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <a href="#" class="btn btn-primary btn-lg-square back-to-top"><i class="fa fa-arrow-up"></i></a>

    <script>
        function ajouterProduit() {
            const container = document.getElementById('produits-container');
            const newRow = document.createElement('div');
            newRow.className = 'produit-row';
            newRow.innerHTML = `
                <div class="row">
                    <div class="col-md-6">
                        <select class="form-select" name="produits[]" required>
                            <option value="">Choisir un produit</option>
                            <?php foreach ($recup2 as $prod) { ?>
                                <option value="<?= $prod['idprod'] ?>"><?= $prod['designation'] ?> - <?= $prod['prix'] ?> FCFA (Stock: <?= $prod['stock'] ?>)</option>
                            <?php } ?>
                        </select>
                    </div>
                    <div class="col-md-4">
                        <input type="number" class="form-control" name="quantites[]" placeholder="Quantité" min="1" required>
                    </div>
                    <div class="col-md-2">
                        <button type="button" class="btn btn-danger" onclick="supprimerProduit(this)"><i class="fas fa-trash"></i></button>
                    </div>
                </div>
            `;
            container.appendChild(newRow);
        }
        
        function supprimerProduit(button) {
            const row = button.closest('.produit-row');
            row.remove();
        }
    </script>
    
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.4/jquery.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0/dist/js/bootstrap.bundle.min.js"></script>
    <script src="lib/wow/wow.min.js"></script>
    <script src="lib/owlcarousel/owl.carousel.min.js"></script>
    <script src="js/main.js"></script>
</body>
</html>