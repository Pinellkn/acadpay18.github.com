<?php
session_start();

// Vérifier si l'utilisateur est connecté
if (!isset($_SESSION['user_id']) && !isset($_SESSION['profil'])) {
    header("Location: connexion.php");
    exit();
}

// Vérifier que c'est bien un client
if ($_SESSION['profil'] !== "CLIENT") {
    header("Location: connexion.php");
    exit();
}

// Récupérer les infos de l'utilisateur (si stockées en session)
$nom_utilisateur = $_SESSION['nom'] ?? "Client";
$email_utilisateur = $_SESSION['email'] ?? "";
?>

<!DOCTYPE html>
<html lang="fr">

<head>
    <meta charset="utf-8">
    <title>Electro - Espace Client</title>
    <meta content="width=device-width, initial-scale=1.0" name="viewport">

    <!-- Google Web Fonts -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link
        href="https://fonts.googleapis.com/css2?family=Open+Sans:wght@400;500;600;700&family=Roboto:wght@400;500;700&display=swap"
        rel="stylesheet">

    <!-- Icon Font Stylesheet -->
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.15.4/css/all.css" />
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.4.1/font/bootstrap-icons.css" rel="stylesheet">

    <!-- Bootstrap & Template Stylesheet -->
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="css/style.css" rel="stylesheet">

    <style>
        .user-info-card {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            border-radius: 15px;
            padding: 30px;
            margin-bottom: 30px;
        }
        
        .feature-card {
            transition: all 0.3s ease;
            border: 1px solid #e0e0e0;
            border-radius: 10px;
            padding: 20px;
            height: 100%;
        }
        
        .feature-card:hover {
            transform: translateY(-5px);
            box-shadow: 0 10px 20px rgba(0,0,0,0.1);
            border-color: #667eea;
        }
        
        .feature-icon {
            font-size: 2.5rem;
            margin-bottom: 15px;
            color: #667eea;
        }
        
        .logout-btn {
            background: #dc3545;
            color: white;
            border: none;
            padding: 10px 20px;
            border-radius: 5px;
            transition: all 0.3s ease;
        }
        
        .logout-btn:hover {
            background: #c82333;
            transform: scale(1.05);
        }
        
        .welcome-banner {
            background: linear-gradient(45deg, #f093fb 0%, #f5576c 100%);
            padding: 20px;
            border-radius: 10px;
            color: white;
            margin-bottom: 30px;
        }
    </style>
</head>

<body>
    <!-- Spinner Start -->
    <div id="spinner"
        class="show bg-white position-fixed translate-middle w-100 vh-100 top-50 start-50 d-flex align-items-center justify-content-center">
        <div class="spinner-border text-primary" style="width: 3rem; height: 3rem;" role="status">
            <span class="sr-only">Loading...</span>
        </div>
    </div>
    <!-- Spinner End -->

    <!-- Topbar Start -->
    <div class="container-fluid px-5 d-none d-lg-block">
        <div class="row gx-0 align-items-center">
            <div class="col-lg-4 text-center text-lg-start mb-lg-0">
                <div class="d-inline-flex align-items-center" style="height: 45px;">
                    <small><i class="far fa-envelope text-primary me-2"></i><?php echo $email_utilisateur; ?></small>
                </div>
            </div>
            <div class="col-lg-4 text-center d-flex align-items-center justify-content-center">
                <h4 class="text-primary m-0">ESPACE CLIENT</h4>
            </div>
            <div class="col-lg-4 text-center text-lg-end">
                <div class="d-inline-flex align-items-center" style="height: 45px;">
                    <a href="logout.php" class="logout-btn">
                        <i class="fas fa-sign-out-alt me-2"></i>Déconnexion
                    </a>
                </div>
            </div>
        </div>
    </div>
    <!-- Topbar End -->

    <!-- Navbar Start -->
    <div class="container-fluid nav-bar p-0">
        <div class="row gx-0 bg-primary px-5 align-items-center">
            <div class="col-12">
                <nav class="navbar navbar-expand-lg navbar-light bg-primary">
                    <a href="login.php" class="navbar-brand">
                        <h1 class="display-5 text-secondary m-0">
                            <i class="fas fa-user-circle text-white me-2"></i>Electro Client
                        </h1>
                    </a>
                    <button class="navbar-toggler ms-auto" type="button" data-bs-toggle="collapse"
                        data-bs-target="#navbarCollapse">
                        <span class="fa fa-bars fa-1x"></span>
                    </button>
                    <div class="collapse navbar-collapse" id="navbarCollapse">
                        <div class="navbar-nav ms-auto py-0">
                            <a href="login.php" class="nav-item nav-link active">Accueil</a>
                            <a href="produits.php" class="nav-item nav-link">Produits</a>
                            <a href="panier.php" class="nav-item nav-link">Panier</a>
                            <a href="commandes.php" class="nav-item nav-link">Mes Commandes</a>
                            <a href="profil.php" class="nav-item nav-link">Mon Profil</a>
                        </div>
                    </div>
                </nav>
            </div>
        </div>
    </div>
    <!-- Navbar End -->

    <!-- Header -->
    <div class="container-fluid page-header py-5">
        <h1 class="text-center text-white display-6 wow fadeInUp" data-wow-delay="0.1s">
            Bienvenue, <?php echo htmlspecialchars($nom_utilisateur); ?> !
        </h1>
    </div>

    <!-- Contenu Principal -->
    <div class="container-fluid py-5">
        <div class="container py-5">
            <!-- Bannière de bienvenue -->
            <div class="welcome-banner wow fadeInUp" data-wow-delay="0.1s">
                <div class="row align-items-center">
                    <div class="col-md-8">
                        <h3><i class="fas fa-gem me-2"></i>Bienvenue dans votre espace personnel</h3>
                        <p class="mb-0">Profitez de toutes les fonctionnalités réservées à nos clients privilégiés.</p>
                    </div>
                    <div class="col-md-4 text-end">
                        <span class="badge bg-light text-primary fs-6 p-3">
                            Client depuis <?php echo date('d/m/Y'); ?>
                        </span>
                    </div>
                </div>
            </div>

            <!-- Cartes de fonctionnalités -->
            <div class="row g-4">
                <div class="col-lg-3 col-md-6 wow fadeInUp" data-wow-delay="0.1s">
                    <div class="feature-card text-center">
                        <div class="feature-icon">
                            <i class="fas fa-shopping-cart"></i>
                        </div>
                        <h4>Boutique</h4>
                        <p>Découvrez nos derniers produits et offres spéciales.</p>
                        <a href="produits.php" class="btn btn-primary btn-sm mt-3">Voir les produits</a>
                    </div>
                </div>

                <div class="col-lg-3 col-md-6 wow fadeInUp" data-wow-delay="0.2s">
                    <div class="feature-card text-center">
                        <div class="feature-icon">
                            <i class="fas fa-box-open"></i>
                        </div>
                        <h4>Mes Commandes</h4>
                        <p>Suivez l'état de vos commandes et consultez votre historique.</p>
                        <a href="commandes.php" class="btn btn-primary btn-sm mt-3">Voir mes commandes</a>
                    </div>
                </div>

                <div class="col-lg-3 col-md-6 wow fadeInUp" data-wow-delay="0.3s">
                    <div class="feature-card text-center">
                        <div class="feature-icon">
                            <i class="fas fa-user-edit"></i>
                        </div>
                        <h4>Mon Profil</h4>
                        <p>Modifiez vos informations personnelles et préférences.</p>
                        <a href="profil.php" class="btn btn-primary btn-sm mt-3">Modifier mon profil</a>
                    </div>
                </div>

                <div class="col-lg-3 col-md-6 wow fadeInUp" data-wow-delay="0.4s">
                    <div class="feature-card text-center">
                        <div class="feature-icon">
                            <i class="fas fa-headset"></i>
                        </div>
                        <h4>Support</h4>
                        <p>Besoin d'aide ? Notre équipe est à votre disposition.</p>
                        <a href="support.php" class="btn btn-primary btn-sm mt-3">Contacter le support</a>
                    </div>
                </div>
            </div>

            <!-- Section informations personnelles -->
            <div class="row mt-5">
                <div class="col-lg-12">
                    <div class="user-info-card wow fadeInUp" data-wow-delay="0.5s">
                        <div class="row align-items-center">
                            <div class="col-md-8">
                                <h3><i class="fas fa-user-circle me-2"></i>Mes Informations</h3>
                                <p class="mb-1"><strong>Nom :</strong> <?php echo htmlspecialchars($nom_utilisateur); ?></p>
                                <p class="mb-1"><strong>Email :</strong> <?php echo htmlspecialchars($email_utilisateur); ?></p>
                                <p class="mb-0"><strong>Type de compte :</strong> Compte Client</p>
                            </div>
                            <div class="col-md-4 text-end">
                                <a href="profil.php" class="btn btn-light btn-lg">
                                    <i class="fas fa-cog me-2"></i>Gérer mon compte
                                </a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Footer -->
    <div class="container-fluid footer py-5 wow fadeIn" data-wow-delay="0.2s">
        <div class="container py-5">
            <div class="row g-5">
                <div class="col-md-6 col-lg-6 col-xl-3">
                    <div class="footer-item d-flex flex-column">
                        <h4 class="text-primary mb-4">Mon Compte</h4>
                        <a href="profil.php"><i class="fas fa-angle-right me-2"></i> Mon Profil</a>
                        <a href="commandes.php"><i class="fas fa-angle-right me-2"></i> Mes Commandes</a>
                        <a href="panier.php"><i class="fas fa-angle-right me-2"></i> Mon Panier</a>
                        <a href="wishlist.php"><i class="fas fa-angle-right me-2"></i> Ma Liste de Souhaits</a>
                        <a href="addresses.php"><i class="fas fa-angle-right me-2"></i> Mes Adresses</a>
                    </div>
                </div>
                <div class="col-md-6 col-lg-6 col-xl-3">
                    <div class="footer-item d-flex flex-column">
                        <h4 class="text-primary mb-4">Boutique</h4>
                        <a href="produits.php"><i class="fas fa-angle-right me-2"></i> Tous les Produits</a>
                        <a href="promotions.php"><i class="fas fa-angle-right me-2"></i> Promotions</a>
                        <a href="nouveautes.php"><i class="fas fa-angle-right me-2"></i> Nouveautés</a>
                        <a href="categories.php"><i class="fas fa-angle-right me-2"></i> Catégories</a>
                    </div>
                </div>
                <div class="col-md-6 col-lg-6 col-xl-3">
                    <div class="footer-item d-flex flex-column">
                        <h4 class="text-primary mb-4">Assistance</h4>
                        <a href="faq.php"><i class="fas fa-angle-right me-2"></i> FAQ</a>
                        <a href="support.php"><i class="fas fa-angle-right me-2"></i> Support Client</a>
                        <a href="livraison.php"><i class="fas fa-angle-right me-2"></i> Livraison</a>
                        <a href="retours.php"><i class="fas fa-angle-right me-2"></i> Retours</a>
                    </div>
                </div>
                <div class="col-md-6 col-lg-6 col-xl-3">
                    <div class="footer-item d-flex flex-column">
                        <h4 class="text-primary mb-4">Contact</h4>
                        <p><i class="fas fa-map-marker-alt me-2"></i> 123 Rue Electro, Paris</p>
                        <p><i class="fas fa-phone me-2"></i> +33 1 23 45 67 89</p>
                        <p><i class="fas fa-envelope me-2"></i> client@electro.com</p>
                        <div class="d-flex mt-3">
                            <a href="#" class="btn btn-primary btn-sm me-2"><i class="fab fa-facebook-f"></i></a>
                            <a href="#" class="btn btn-primary btn-sm me-2"><i class="fab fa-twitter"></i></a>
                            <a href="#" class="btn btn-primary btn-sm me-2"><i class="fab fa-instagram"></i></a>
                        </div>
                    </div>
                </div>
            </div>
            
            <hr class="mt-5">
            
            <div class="row mt-4">
                <div class="col-md-6">
                    <p class="mb-0">&copy; <?php echo date('Y'); ?> Electro. Tous droits réservés.</p>
                </div>
                <div class="col-md-6 text-end">
                    <p class="mb-0">
                        Connecté en tant que : <strong><?php echo htmlspecialchars($nom_utilisateur); ?></strong>
                    </p>
                </div>
            </div>
        </div>
    </div>

    <!-- Bouton retour haut -->
    <a href="#" class="btn btn-primary btn-lg-square back-to-top"><i class="fa fa-arrow-up"></i></a>

    <!-- JS -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.4/jquery.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0/dist/js/bootstrap.bundle.min.js"></script>
    <script src="lib/wow/wow.min.js"></script>
    <script src="lib/owlcarousel/owl.carousel.min.js"></script>
    <script src="js/main.js"></script>

    <script>
        // Initialiser les animations
        new WOW().init();
        
        // Message de bienvenue
        $(document).ready(function() {
            setTimeout(function() {
                $('.welcome-banner').addClass('pulse');
                setTimeout(function() {
                    $('.welcome-banner').removeClass('pulse');
                }, 1000);
            }, 1000);
        });
    </script>
</body>

</html>