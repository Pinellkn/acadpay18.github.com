<?php
     include("connect.php");
     $sql1="SELECT * FROM categorie";
        $exe1 = $bdd->query($sql1);
        $recup1 = $exe1->fetchAll();

     $num=$_GET['id'];
     $sql="SELECT * FROM produit WHERE idprod = $num";
        $exe = $bdd->query($sql);
        $recup = $exe->fetchAll();  
        foreach($recup as $ligne){
            $idprod =$ligne["idprod"];
            $designation =$ligne["designation"];
            $prix =$ligne["prix"];
            $stock =$ligne["stock"];
            $descript =$ligne["description"];
            $photo =$ligne["photo"];
            $codecat =$ligne["codecat"];
        }

     if(isset($_POST["valider"])){

        $designation =$_POST["designation"];
        $prix =$_POST["prix"];
        $stock =$_POST["stock"];
        $descript =$_POST["description"];
        $codecat =$_POST["categorie"];
        
        // Gestion de l'image : si nouvelle image uploadée, sinon garder l'ancienne
        if(isset($_FILES['image']) && $_FILES['image']['error'] == 0 && $_FILES['image']['size'] > 0){
            // Une nouvelle image a été uploadée
            $photo = basename($_FILES['image']['name']);
            $dossier ="photos/";
            $lien = $dossier.$photo;
            
            if(move_uploaded_file($_FILES['image']['tmp_name'],$lien)){
                $image_updated = true;
            } else {
                echo "<script>alert('Erreur lors du téléchargement de l\'image')</script>";
                $image_updated = false;
                $lien = $photo; // Garder l'ancien lien
            }
        } else {
            // Aucune nouvelle image, garder l'ancienne
            $lien = $photo;
            $image_updated = true; // On considère que c'est OK car on garde l'ancienne
        }
        
        if($image_updated){
            $sql2= $bdd->prepare("UPDATE produit SET designation=?, prix=?, stock=?, description=?, photo=?, codecat=? WHERE idprod = ?");
            $exe2 = $sql2->execute([$designation, $prix, $stock, $descript, $lien, $codecat, $num]);
       
            if(!$exe2){
                echo "<script>alert('Echec modification')</script>";
                header("refresh: 0.5; url=addproduit.php");
                exit();
            }else{
                echo "<script>alert('Modification réussie')</script>";
                header("refresh: 0.5; url=listeprod.php");
                exit();
            }
        } else {
            echo "<script>alert('Erreur lors du traitement de l\'image')</script>";
            header("refresh: 0.5; url=listeprod.php");
            exit();
        }
     }
?>

<!DOCTYPE html>
<html lang="fr">

<head>
    <meta charset="utf-8">
    <title>Electro - Modifier un Produit</title>
    <meta content="width=device-width, initial-scale=1.0" name="viewport">

    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link
        href="https://fonts.googleapis.com/css2?family=Open+Sans:wght@400;500;600;700&family=Roboto:wght@400;500;700&display=swap"
        rel="stylesheet">

    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.15.4/css/all.css" />
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.4.1/font/bootstrap-icons.css" rel="stylesheet">

    <link href="lib/animate/animate.min.css" rel="stylesheet">
    <link href="lib/owlcarousel/assets/owl.carousel.min.css" rel="stylesheet">

    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="css/style.css" rel="stylesheet">
    
    <style>
        .current-image-container {
            border: 2px dashed #ccc;
            padding: 10px;
            border-radius: 8px;
            margin-bottom: 15px;
            background-color: #f8f9fa;
        }
        
        .current-image-label {
            font-weight: bold;
            color: #666;
            margin-bottom: 10px;
            display: block;
        }
        
        .image-preview {
            max-width: 200px;
            max-height: 200px;
            object-fit: contain;
        }
        
        .optional-label {
            color: #6c757d;
            font-size: 0.9em;
        }
    </style>
</head>

<body>

    <div id="spinner"
        class="show bg-white position-fixed translate-middle w-100 vh-100 top-50 start-50 d-flex align-items-center justify-content-center">
        <div class="spinner-border text-primary" style="width: 3rem; height: 3rem;" role="status">
            <span class="sr-only">Loading...</span>
        </div>
    </div>

    <div class="container-fluid px-5 d-none border-bottom d-lg-block">
        <div class="row gx-0 align-items-center">
            <div class="col-lg-4 text-center text-lg-start mb-lg-0">
                <div class="d-inline-flex align-items-center" style="height: 45px;">
                    <a href="#" class="text-muted me-2"></a><small>  </small>
                    <a href="#" class="text-muted mx-2"></a><small> </small>
                    <a href="#" class="text-muted ms-2"></a>
                </div>
            </div>
            <div class="col-lg-4 text-center d-flex align-items-center justify-content-center">
                <small class="text-dark"></small>
                <a href="#" class="text-muted"></a>
            </div>
            <div class="col-lg-4 text-center text-lg-end">
                <div class="d-inline-flex align-items-center" style="height: 45px;">
                    <a href="#" class="text-muted"></a>
                </div>
            </div>
        </div>
    </div>

    <div class="container-fluid nav-bar p-0">
        <div class="row gx-0 bg-primary px-5 align-items-center">
            <div class="col-12">
                <nav class="navbar navbar-expand-lg navbar-light bg-primary">
                    <a href="#" class="navbar-brand d-block d-lg-none">
                        <h1 class="display-5 text-secondary m-0"><i
                                class="fas fa-shopping-bag text-white me-2"></i>Electro</h1>
                    </a>
                    <button class="navbar-toggler ms-auto" type="button" data-bs-toggle="collapse"
                        data-bs-target="#navbarCollapse">
                        <span class="fa fa-bars fa-1x"></span>
                    </button>
                    <div class="collapse navbar-collapse" id="navbarCollapse">
                        <div class="navbar-nav ms-auto py-0">
                        <a href="sessionadmin.php" class="nav-item nav-link">Accueil</a>
                            <a href="listecat.php" class="nav-item nav-link">Catégorie</a>
                            <a href="listeprod.php" class="nav-item nav-link">Produit</a>
                            <a href="listeclient.php" class="nav-item nav-link">Client</a>
                            <a href="listecommande.php" class="nav-item nav-link">Commande</a>
                        </div>
                        <a href="#"></a>
                    </div>
                </nav>
            </div>
        </div>
    </div>

    <div class="container-fluid page-header py-5">
        <h1 class="text-center text-white display-6 wow fadeInUp" data-wow-delay="0.1s">Modification de produit</h1>
    </div>

    <div class="container-fluid contact py-5">
        <div class="container py-5">
            <div class="p-5 bg-light rounded">
                <div class="text-center mx-auto wow fadeInUp mb-5" data-wow-delay="0.1s" style="max-width: 800px;">
                    <h4 class="text-primary border-bottom border-primary border-2 d-inline-block pb-2">Formulaire de modification du produit <?= $designation ?> </h4>
                    <p>Renseignez les informations</p>
                </div>

                <form action="updateproduit.php?id=<?= $num ?>" method="POST" class="wow fadeInUp" data-wow-delay="0.3s" enctype="multipart/form-data">
                    <div class="row g-4">
                        <div class="col-lg-6">
                            <div class="form-floating">
                                <input type="text" class="form-control" id="designation" name="designation" value="<?= $designation  ?>" required>
                                <label for="libelle">Désignation</label>
                            </div>
                        </div> 
                        <div class="col-lg-6">
                            <div class="form-floating">
                                <input type="number" class="form-control" id="prix" name="prix" step="0.01" min="0" value="<?= $prix  ?>" required>
                                <label for="libelle">Prix</label>
                            </div>
                        </div> 
                        <div class="col-lg-6">
                            <div class="form-floating">
                                <input type="number" class="form-control" id="stock" name="stock" min="0" value="<?= $stock  ?>" required>
                                <label for="libelle">Stock</label>
                            </div>
                        </div>
                        <div class="col-lg-6">
                            <div class="form-floating">
                                <select class="form-select" id="categorie" name="categorie" required>
                                    <option selected disabled>Choisir une catégorie</option>
                                    <?php foreach ($recup1 as $cat ) {
                                        if($cat['codecat'] == $codecat) {
                                    ?>
                                        <option value="<?= $cat['codecat'] ?>" Selected><?= $cat['libelle'] ?></option>
                                    <?php } else { ?>
                                        <option value="<?= $cat['codecat'] ?>"><?= $cat['libelle'] ?></option>
                                    <?php } 
                                    }?>
                                </select>
                                <label for="categorie">Catégorie</label>
                            </div>
                        </div>
                        <div class="col-12">
                            <div class="current-image-container">
                                <span class="current-image-label">Image actuelle :</span>
                                <?php if($photo && file_exists($photo)): ?>
                                    <img class="image-preview" src="<?= $photo ?>" alt="<?= $designation ?>">
                                <?php else: ?>
                                    <div class="alert alert-warning">
                                        <i class="fas fa-exclamation-triangle"></i> Aucune image disponible pour ce produit
                                    </div>
                                <?php endif; ?>
                            </div>
                        </div>
                        <div class="col-12">
                            <div class="mb-3">
                                <label for="image" class="form-label">
                                    Nouvelle image du produit
                                </label>
                                <input class="form-control" type="file" id="image" name="image" accept="image/*">
                            </div>
                            <div id="newImagePreview" class="mt-3" style="display: none;">
                                <span class="current-image-label">Aperçu de la nouvelle image :</span>
                                <img id="previewImage" class="image-preview" src="" alt="Aperçu">
                            </div>
                        </div>                   
                        <div class="col-12">
                            <div class="form-floating">
                                <textarea class="form-control" id="description" name="description" style="height: 120px"><?= $descript ?></textarea>
                                <label for="description">Description</label>
                            </div>
                        </div>
                        <div class="col-12 mt-4">
                            <button type="submit" class="btn btn-primary w-100 py-3" name="valider">
                                <i class="fas fa-save me-2"></i>Modifier le produit
                            </button>
                        </div>
                    </div>
                </form>

            </div>
        </div>
    </div>

    
    <div class="container-fluid footer py-5 wow fadeIn" data-wow-delay="0.2s">
        <div class="container py-5">

            <div class="row g-5">
                <div class="col-md-6 col-lg-6 col-xl-3">
                    <div class="footer-item d-flex flex-column">
                        <div class="footer-item">
                            <h4 class="text-primary mb-4">Newsletter</h4>
                            <p class="mb-3">Dolor amet sit justo amet elitr clita ipsum elitr est.Lorem ipsum dolor sit
                                amet, consectetur adipiscing elit consectetur adipiscing elit.</p>
                            <div class="position-relative mx-auto rounded-pill">
                                <input class="form-control rounded-pill w-100 py-3 ps-4 pe-5" type="text"
                                    placeholder="Enter your email">
                                <button type="button"
                                    class="btn btn-primary rounded-pill position-absolute top-0 end-0 py-2 mt-2 me-2">SignUp</button>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-md-6 col-lg-6 col-xl-3">
                    <div class="footer-item d-flex flex-column">
                        <h4 class="text-primary mb-4">Customer Service</h4>
                        <a href="#" class=""><i class="fas fa-angle-right me-2"></i> Contact Us</a>
                        <a href="#" class=""><i class="fas fa-angle-right me-2"></i> Returns</a>
                        <a href="#" class=""><i class="fas fa-angle-right me-2"></i> Order History</a>
                        <a href="#" class=""><i class="fas fa-angle-right me-2"></i> Site Map</a>
                        <a href="#" class=""><i class="fas fa-angle-right me-2"></i> Testimonials</a>
                        <a href="#" class=""><i class="fas fa-angle-right me-2"></i> My Account</a>
                        <a href="#" class=""><i class="fas fa-angle-right me-2"></i> Unsubscribe Notification</a>
                    </div>
                </div>
                <div class="col-md-6 col-lg-6 col-xl-3">
                    <div class="footer-item d-flex flex-column">
                        <h4 class="text-primary mb-4">Information</h4>
                        <a href="#" class=""><i class="fas fa-angle-right me-2"></i> About Us</a>
                        <a href="#" class=""><i class="fas fa-angle-right me-2"></i> Delivery infomation</a>
                        <a href="#" class=""><i class="fas fa-angle-right me-2"></i> Privacy Policy</a>
                        <a href="#" class=""><i class="fas fa-angle-right me-2"></i> Terms & Conditions</a>
                        <a href="#" class=""><i class="fas fa-angle-right me-2"></i> Warranty</a>
                        <a href="#" class=""><i class="fas fa-angle-right me-2"></i> FAQ</a>
                        <a href="#" class=""><i class="fas fa-angle-right me-2"></i> Seller Login</a>
                    </div>
                </div>
                <div class="col-md-6 col-lg-6 col-xl-3">
                    <div class="footer-item d-flex flex-column">
                        <h4 class="text-primary mb-4">Extras</h4>
                        <a href="#" class=""><i class="fas fa-angle-right me-2"></i> Brands</a>
                        <a href="#" class=""><i class="fas fa-angle-right me-2"></i> Gift Vouchers</a>
                        <a href="#" class=""><i class="fas fa-angle-right me-2"></i> Affiliates</a>
                        <a href="#" class=""><i class="fas fa-angle-right me-2"></i> Wishlist</a>
                        <a href="#" class=""><i class="fas fa-angle-right me-2"></i> Order History</a>
                        <a href="#" class=""><i class="fas fa-angle-right me-2"></i> Track Your Order</a>
                        <a href="#" class=""><i class="fas fa-angle-right me-2"></i> Track Your Order</a>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <a href="#" class="btn btn-primary btn-lg-square back-to-top"><i class="fa fa-arrow-up"></i></a>

    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.4/jquery.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0/dist/js/bootstrap.bundle.min.js"></script>
    <script src="lib/wow/wow.min.js"></script>
    <script src="lib/owlcarousel/owl.carousel.min.js"></script>
    <script src="js/main.js"></script>
    
    <script>
        // Aperçu de la nouvelle image sélectionnée
        document.getElementById('image').addEventListener('change', function(e) {
            const previewContainer = document.getElementById('newImagePreview');
            const previewImage = document.getElementById('previewImage');
            const file = e.target.files[0];
            
            if (file) {
                const reader = new FileReader();
                
                reader.onload = function(e) {
                    previewImage.src = e.target.result;
                    previewContainer.style.display = 'block';
                }
                
                reader.readAsDataURL(file);
            } else {
                previewContainer.style.display = 'none';
                previewImage.src = '';
            }
        });
        
        // Validation du formulaire
        document.querySelector('form').addEventListener('submit', function(e) {
            const designation = document.getElementById('designation').value.trim();
            const prix = document.getElementById('prix').value;
            const stock = document.getElementById('stock').value;
            const categorie = document.getElementById('categorie').value;
            
            if (!designation || !prix || !stock || !categorie) {
                e.preventDefault();
                alert('Veuillez remplir tous les champs obligatoires.');
                return false;
            }
            
            if (prix <= 0) {
                e.preventDefault();
                alert('Le prix doit être supérieur à 0.');
                return false;
            }
            
            if (stock < 0) {
                e.preventDefault();
                alert('Le stock ne peut pas être négatif.');
                return false;
            }
            
            // Validation de l'image (facultative)
            const imageInput = document.getElementById('image');
            if (imageInput.files.length > 0) {
                const file = imageInput.files[0];
                const validTypes = ['image/jpeg', 'image/png', 'image/gif', 'image/webp'];
                const maxSize = 2 * 1024 * 1024; // 2MB
                
                if (!validTypes.includes(file.type)) {
                    e.preventDefault();
                    alert('Format d\'image non supporté. Utilisez JPG, PNG, GIF ou WEBP.');
                    return false;
                }
                
                if (file.size > maxSize) {
                    e.preventDefault();
                    alert('L\'image est trop volumineuse. Taille max: 2MB.');
                    return false;
                }
            }
            
            return true;
        });
    </script>
</body>

</html>