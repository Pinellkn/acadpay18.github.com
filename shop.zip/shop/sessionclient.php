<?php
session_start();
include("connect.php");

if(!isset($_SESSION['client_id'])){
    header("Location: login.php");
    exit();
}

$client_id = $_SESSION['client_id'];

$sql_client = $bdd->prepare("SELECT * FROM client WHERE idcli = ?");
$sql_client->execute([$client_id]);
$client = $sql_client->fetch();

$sql_commandes = $bdd->prepare("SELECT * FROM commande WHERE idcli = ? ORDER BY datecmd DESC");
$sql_commandes->execute([$client_id]);
$commandes = $sql_commandes->fetchAll();

$sql_commandes_count = $bdd->prepare("SELECT COUNT(*) as total FROM commande WHERE idcli = ?");
$sql_commandes_count->execute([$client_id]);
$total_commandes = $sql_commandes_count->fetch()['total'];

$sql_total_depense = $bdd->prepare("SELECT SUM(montant) as total FROM commande WHERE idcli = ? AND etat = 'Livrée'");
$sql_total_depense->execute([$client_id]);
$total_depense = $sql_total_depense->fetch()['total'] ?? 0;
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="utf-8">
    <title>Electro - Mon Compte</title>
    <meta content="width=device-width, initial-scale=1.0" name="viewport">

    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Open+Sans:wght@400;500;600;700&family=Roboto:wght@400;500;700&display=swap" rel="stylesheet">

    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.15.4/css/all.css" />
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.4.1/font/bootstrap-icons.css" rel="stylesheet">

    <link href="lib/animate/animate.min.css" rel="stylesheet">
    <link href="lib/owlcarousel/assets/owl.carousel.min.css" rel="stylesheet">

    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="css/style.css" rel="stylesheet">
    
    <style>
        .profile-card {
            background: white;
            border-radius: 10px;
            padding: 30px;
            box-shadow: 0 4px 12px rgba(0, 0, 0, 0.08);
            margin-bottom: 30px;
        }
        
        .profile-header {
            display: flex;
            align-items: center;
            margin-bottom: 25px;
        }
        
        .profile-avatar {
            width: 80px;
            height: 80px;
            border-radius: 50%;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            display: flex;
            align-items: center;
            justify-content: center;
            color: white;
            font-size: 32px;
            margin-right: 20px;
        }
        
        .profile-info h3 {
            margin: 0;
            color: #333;
            font-weight: 700;
        }
        
        .profile-info p {
            margin: 5px 0 0 0;
            color: #666;
        }
        
        .info-item {
            display: flex;
            margin-bottom: 15px;
            padding-bottom: 15px;
            border-bottom: 1px solid #f0f0f0;
        }
        
        .info-item:last-child {
            border-bottom: none;
            margin-bottom: 0;
            padding-bottom: 0;
        }
        
        .info-label {
            font-weight: 600;
            color: #555;
            min-width: 120px;
        }
        
        .info-value {
            color: #333;
        }
        
        .stat-card {
            background: white;
            border-radius: 10px;
            padding: 20px;
            box-shadow: 0 4px 12px rgba(0, 0, 0, 0.08);
            text-align: center;
            height: 100%;
            transition: transform 0.3s ease;
        }
        
        .stat-card:hover {
            transform: translateY(-5px);
        }
        
        .stat-icon {
            width: 50px;
            height: 50px;
            border-radius: 10px;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 20px;
            margin: 0 auto 15px;
            color: white;
        }
        
        .stat-number {
            font-size: 1.8rem;
            font-weight: 700;
            color: #333;
            margin-bottom: 5px;
        }
        
        .stat-title {
            color: #666;
            font-size: 0.9rem;
        }
        
        .table-responsive {
            border-radius: 10px;
            overflow: hidden;
            box-shadow: 0 0 20px rgba(0, 0, 0, 0.1);
        }
        
        .table th {
            background-color: #ffa704;
            color: white;
            font-weight: 600;
            border: none;
        }
        
        .etat-badge {
            padding: 5px 10px;
            border-radius: 20px;
            font-size: 0.8rem;
            font-weight: 600;
        }
        
        .etat-en-cours {
            background-color: #fff3cd;
            color: #856404;
        }
        
        .etat-livree {
            background-color: #d1f7c4;
            color: #2e7d32;
        }
        
        .etat-annulee {
            background-color: #ffcdd2;
            color: #c62828;
        }
        
        .btn-deconnexion {
            background-color: #dc3545;
            color: white;
            border: none;
            padding: 8px 20px;
            border-radius: 5px;
            cursor: pointer;
            transition: background-color 0.3s ease;
        }
        
        .btn-deconnexion:hover {
            background-color: #c82333;
        }
        
        .section-title {
            color: #333;
            font-weight: 600;
            margin-bottom: 20px;
            padding-bottom: 10px;
            border-bottom: 2px solid #f0f0f0;
        }
        
        .welcome-message {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            border-radius: 10px;
            padding: 30px;
            margin-bottom: 30px;
            box-shadow: 0 6px 20px rgba(102, 126, 234, 0.3);
        }
        
        .welcome-title {
            font-size: 1.8rem;
            font-weight: 700;
            margin-bottom: 10px;
        }
        
        .welcome-text {
            opacity: 0.9;
            font-size: 1rem;
        }
        
        .produit-list {
            font-size: 0.85rem;
        }
        
        .produit-item {
            padding: 3px 0;
            border-bottom: 1px solid #eee;
        }
        
        .produit-item:last-child {
            border-bottom: none;
        }
    </style>
</head>

<body>
    <div id="spinner" class="show bg-white position-fixed translate-middle w-100 vh-100 top-50 start-50 d-flex align-items-center justify-content-center">
        <div class="spinner-border text-primary" style="width: 3rem; height: 3rem;" role="status">
            <span class="sr-only">Loading...</span>
        </div>
    </div>

    <div class="container-fluid px-5 d-none border-bottom d-lg-block">
        <div class="row gx-0 align-items-center">
            <div class="col-lg-4 text-center text-lg-start mb-lg-0">
                <div class="d-inline-flex align-items-center" style="height: 45px;">
                    <a href="#" class="text-muted me-2"></a><small>  </small>
                    <a href="#" class="text-muted mx-2"></a><small> </small>
                    <a href="#" class="text-muted ms-2"></a>
                </div>
            </div>
            <div class="col-lg-4 text-center d-flex align-items-center justify-content-center">
                <small class="text-dark"></small>
                <a href="#" class="text-muted"></a>
            </div>
            <div class="col-lg-4 text-center text-lg-end">
                <div class="d-inline-flex align-items-center" style="height: 45px;">
                    <a href="#" class="text-muted"></a>
                </div>
            </div>
        </div>
    </div>

    <div class="container-fluid nav-bar p-0">
        <div class="row gx-0 bg-primary px-5 align-items-center">
            <div class="col-12">
                <nav class="navbar navbar-expand-lg navbar-light bg-primary">
                    <a href="#" class="navbar-brand d-block d-lg-none">
                        <h1 class="display-5 text-secondary m-0"><i class="fas fa-shopping-bag text-white me-2"></i>Electro</h1>
                    </a>
                    <button class="navbar-toggler ms-auto" type="button" data-bs-toggle="collapse" data-bs-target="#navbarCollapse">
                        <span class="fa fa-bars fa-1x"></span>
                    </button>
                    <div class="collapse navbar-collapse" id="navbarCollapse">
                        <div class="navbar-nav ms-auto py-0">
                            <a href="sessionclient.php" class="nav-item nav-link active">Mon Compte</a>
                            <a href="boutique.php" class="nav-item nav-link">Boutique</a>
                            <a href="mescommandes.php" class="nav-item nav-link">Mes Commandes</a>
                            <a href="panier.php" class="nav-item nav-link">Panier</a>
                            <a href="logout.php" class="nav-item nav-link">Déconnexion</a>
                        </div>
                    </div>
                </nav>
            </div>
        </div>
    </div>

    <div class="container-fluid page-header py-5">
        <h1 class="text-center text-white display-6 wow fadeInUp" data-wow-delay="0.1s">Mon Compte Client</h1>
    </div>

    <div class="container-fluid contact py-5">
        <div class="container py-5">
            <div class="welcome-message">
                <div class="row align-items-center">
                    <div class="col-md-8">
                        <h2 class="welcome-title">Bienvenue, <?= $client['prenom'] ?> <?= $client['nom'] ?> !</h2>
                        <p class="welcome-text">Gérez vos informations personnelles, consultez vos commandes et suivez vos achats.</p>
                    </div>
                    <div class="col-md-4 text-center">
                        <i class="fas fa-user-circle fa-4x opacity-75"></i>
                    </div>
                </div>
            </div>
            
            <div class="row g-4 mb-5">
                <div class="col-md-4">
                    <div class="stat-card">
                        <div class="stat-icon" style="background-color: #007bff;">
                            <i class="fas fa-shopping-cart"></i>
                        </div>
                        <div class="stat-number"><?= $total_commandes ?></div>
                        <div class="stat-title">Commandes passées</div>
                    </div>
                </div>
                
                <div class="col-md-4">
                    <div class="stat-card">
                        <div class="stat-icon" style="background-color: #28a745;">
                            <i class="fas fa-money-bill-wave"></i>
                        </div>
                        <div class="stat-number"><?= number_format($total_depense, 0, ',', ' ') ?> FCFA</div>
                        <div class="stat-title">Total dépensé</div>
                    </div>
                </div>
                
                <div class="col-md-4">
                    <div class="stat-card">
                        <div class="stat-icon" style="background-color: #ffc107;">
                            <i class="fas fa-star"></i>
                        </div>
                        <div class="stat-number">Client</div>
                        <div class="stat-title">Statut</div>
                    </div>
                </div>
            </div>
            
            <div class="row g-4">
                <div class="col-lg-4">
                    <div class="profile-card">
                        <div class="profile-header">
                            <div class="profile-avatar">
                                <?= strtoupper(substr($client['prenom'], 0, 1) . substr($client['nom'], 0, 1)) ?>
                            </div>
                            <div class="profile-info">
                                <h3><?= $client['prenom'] ?> <?= $client['nom'] ?></h3>
                                <p>Client depuis <?= date('Y') ?></p>
                            </div>
                        </div>
                        
                        <div class="profile-details">
                            <div class="info-item">
                                <span class="info-label">Téléphone:</span>
                                <span class="info-value"><?= $client['tel'] ?></span>
                            </div>
                            
                            <div class="info-item">
                                <span class="info-label">Adresse:</span>
                                <span class="info-value"><?= $client['adresse'] ?? 'Non renseignée' ?></span>
                            </div>
                            
                            <div class="info-item">
                                <span class="info-label">ID Client:</span>
                                <span class="info-value">#<?= str_pad($client['idcli'], 6, '0', STR_PAD_LEFT) ?></span>
                            </div>
                            
                            <div class="info-item">
                                <span class="info-label">Statut:</span>
                                <span class="info-value"><span style="color: #28a745; font-weight: 600;">●</span> Actif</span>
                            </div>
                        </div>
                        
                        <div class="mt-4">
                            <a href="modifierprofil.php" class="btn btn-primary w-100 mb-2">
                                <i class="fas fa-edit me-2"></i>Modifier mon profil
                            </a>
                            <a href="logout.php" class="btn btn-danger w-100">
                                <i class="fas fa-sign-out-alt me-2"></i>Déconnexion
                            </a>
                        </div>
                    </div>
                </div>
                
                <div class="col-lg-8">
                    <div class="bg-light rounded p-4">
                        <h4 class="section-title">Mes Commandes Récentes</h4>
                        <?php if(count($commandes) > 0): ?>
                            <div class="table-responsive">
                                <table class="table table-striped table-hover">
                                    <thead>
                                        <tr>
                                            <th scope="col">N° Commande</th>
                                            <th scope="col">Date</th>
                                            <th scope="col">Produits</th>
                                            <th scope="col">Montant</th>
                                            <th scope="col">État</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php foreach($commandes as $cmd): 
                                            $etatClass = '';
                                            if($cmd['etat'] == 'En cours') $etatClass = 'etat-en-cours';
                                            elseif($cmd['etat'] == 'Livrée') $etatClass = 'etat-livree';
                                            elseif($cmd['etat'] == 'Annulée') $etatClass = 'etat-annulee';
                                            
                                            $sql_lignes = $bdd->prepare("SELECT p.designation, lc.quantite 
                                                                        FROM ligne_commande lc 
                                                                        JOIN produit p ON lc.idprod = p.idprod 
                                                                        WHERE lc.idcmd = ?");
                                            $sql_lignes->execute([$cmd['idcmd']]);
                                            $lignes = $sql_lignes->fetchAll();
                                        ?>
                                        <tr>
                                            <th scope="row">CMD-<?= str_pad($cmd['idcmd'], 6, '0', STR_PAD_LEFT) ?></th>
                                            <td><?= $cmd['datecmd'] ?></td>
                                            <td>
                                                <div class="produit-list">
                                                    <?php if(count($lignes) > 0): ?>
                                                        <?php foreach($lignes as $ligne): ?>
                                                            <div class="produit-item">
                                                                <?= $ligne['designation'] ?> (x<?= $ligne['quantite'] ?>)
                                                            </div>
                                                        <?php endforeach; ?>
                                                    <?php else: ?>
                                                        <div class="text-muted">Aucun produit</div>
                                                    <?php endif; ?>
                                                </div>
                                            </td>
                                            <td><?= number_format($cmd['montant'], 0, ',', ' ') ?> FCFA</td>
                                            <td>
                                                <span class="etat-badge <?= $etatClass ?>">
                                                    <?= $cmd['etat'] ?>
                                                </span>
                                            </td>
                                        </tr>
                                        <?php endforeach; ?>
                                    </tbody>
                                </table>
                            </div>
                            <div class="text-center mt-3">
                                <a href="mescommandes.php" class="btn btn-outline-primary">Voir toutes mes commandes</a>
                            </div>
                        <?php else: ?>
                            <div class="text-center py-5">
                                <i class="fas fa-shopping-cart fa-3x text-muted mb-3"></i>
                                <h5 class="text-muted">Aucune commande pour le moment</h5>
                                <p class="text-muted">Commencez vos achats dans notre boutique</p>
                                <a href="boutique.php" class="btn btn-primary mt-2">
                                    <i class="fas fa-store me-2"></i>Visiter la boutique
                                </a>
                            </div>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="container-fluid footer py-5 wow fadeIn" data-wow-delay="0.2s">
        <div class="container py-5">
            <div class="row g-5">
                <div class="col-md-6 col-lg-6 col-xl-3">
                    <div class="footer-item d-flex flex-column">
                        <div class="footer-item">
                            <h4 class="text-primary mb-4">Newsletter</h4>
                            <p class="mb-3">Dolor amet sit justo amet elitr clita ipsum elitr est.Lorem ipsum dolor sit amet, consectetur adipiscing elit consectetur adipiscing elit.</p>
                            <div class="position-relative mx-auto rounded-pill">
                                <input class="form-control rounded-pill w-100 py-3 ps-4 pe-5" type="text" placeholder="Entrez votre email">
                                <button type="button" class="btn btn-primary rounded-pill position-absolute top-0 end-0 py-2 mt-2 me-2">S'inscrire</button>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-md-6 col-lg-6 col-xl-3">
                    <div class="footer-item d-flex flex-column">
                        <h4 class="text-primary mb-4">Service Client</h4>
                        <a href="#" class=""><i class="fas fa-angle-right me-2"></i> Contactez-nous</a>
                        <a href="#" class=""><i class="fas fa-angle-right me-2"></i> Retours</a>
                        <a href="#" class=""><i class="fas fa-angle-right me-2"></i> Historique des Commandes</a>
                        <a href="#" class=""><i class="fas fa-angle-right me-2"></i> Plan du Site</a>
                        <a href="#" class=""><i class="fas fa-angle-right me-2"></i> Témoignages</a>
                        <a href="#" class=""><i class="fas fa-angle-right me-2"></i> Mon Compte</a>
                        <a href="#" class=""><i class="fas fa-angle-right me-2"></i> Désinscription aux Notifications</a>
                    </div>
                </div>
                <div class="col-md-6 col-lg-6 col-xl-3">
                    <div class="footer-item d-flex flex-column">
                        <h4 class="text-primary mb-4">Informations</h4>
                        <a href="#" class=""><i class="fas fa-angle-right me-2"></i> À propos de nous</a>
                        <a href="#" class=""><i class="fas fa-angle-right me-2"></i> Informations de livraison</a>
                        <a href="#" class=""><i class="fas fa-angle-right me-2"></i> Politique de confidentialité</a>
                        <a href="#" class=""><i class="fas fa-angle-right me-2"></i> Conditions générales</a>
                        <a href="#" class=""><i class="fas fa-angle-right me-2"></i> Garantie</a>
                        <a href="#" class=""><i class="fas fa-angle-right me-2"></i> FAQ</a>
                        <a href="#" class=""><i class="fas fa-angle-right me-2"></i> Connexion Vendeur</a>
                    </div>
                </div>
                <div class="col-md-6 col-lg-6 col-xl-3">
                    <div class="footer-item d-flex flex-column">
                        <h4 class="text-primary mb-4">Extras</h4>
                        <a href="#" class=""><i class="fas fa-angle-right me-2"></i> Marques</a>
                        <a href="#" class=""><i class="fas fa-angle-right me-2"></i> Chèques-cadeaux</a>
                        <a href="#" class=""><i class="fas fa-angle-right me-2"></i> Affiliés</a>
                        <a href="#" class=""><i class="fas fa-angle-right me-2"></i> Liste de souhaits</a>
                        <a href="#" class=""><i class="fas fa-angle-right me-2"></i> Historique des Commandes</a>
                        <a href="#" class=""><i class="fas fa-angle-right me-2"></i> Suivre votre Commande</a>
                        <a href="#" class=""><i class="fas fa-angle-right me-2"></i> Suivre votre Commande</a>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <a href="#" class="btn btn-primary btn-lg-square back-to-top"><i class="fa fa-arrow-up"></i></a>

    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.4/jquery.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0/dist/js/bootstrap.bundle.min.js"></script>
    <script src="lib/wow/wow.min.js"></script>
    <script src="lib/owlcarousel/owl.carousel.min.js"></script>
    <script src="js/main.js"></script>
</body>
</html>