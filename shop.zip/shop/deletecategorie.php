<?php
include("connect.php");

if(isset($_GET['id'])){
    $id = $_GET['id'];
    
    $sql = $bdd->prepare("SELECT COUNT(*) as count FROM produit WHERE codecat = ?");
    $sql->execute([$id]);
    $result = $sql->fetch();
    
    if($result['count'] > 0){
        echo "<script>alert('Impossible de supprimer cette catégorie car elle est utilisée par des produits')</script>";
        header("refresh: 0.5 url=listecat.php");
    }else{
        $sql = $bdd->prepare("DELETE FROM categorie WHERE codecat = ?");
        $exe = $sql->execute([$id]);
        
        if($exe){
            echo "<script>alert('Catégorie supprimée avec succès')</script>";
            header("refresh: 0.5 url=listecat.php");
        }else{
            echo "<script>alert('Erreur lors de la suppression')</script>";
            header("refresh: 0.5 url=listecat.php");
        }
    }
}else{
    header("refresh: 0.5 url=listecat.php");
}
?>