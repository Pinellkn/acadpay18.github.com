<?php
     include("connect.php");

        $sql="SELECT * FROM categorie";
        $exe = $bdd->query($sql);
        $recup = $exe->fetchAll();

?>

<!DOCTYPE html>
<html lang="fr">

<head>
    <meta charset="utf-8">
    <title>Electro - Gestion des Produits</title>
    <meta content="width=device-width, initial-scale=1.0" name="viewport">
    <meta content="" name="keywords">
    <meta content="" name="description">

    <!-- Google Web Fonts -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link
        href="https://fonts.googleapis.com/css2?family=Open+Sans:wght@400;500;600;700&family=Roboto:wght@400;500;700&display=swap"
        rel="stylesheet">

    <!-- Icon Font Stylesheet -->
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.15.4/css/all.css" />
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.4.1/font/bootstrap-icons.css" rel="stylesheet">

    <!-- Libraries Stylesheet -->
    <link href="lib/animate/animate.min.css" rel="stylesheet">
    <link href="lib/owlcarousel/assets/owl.carousel.min.css" rel="stylesheet">

    <!-- Customized Bootstrap Stylesheet -->
    <link href="css/bootstrap.min.css" rel="stylesheet">

    <!-- Template Stylesheet -->
    <link href="css/style.css" rel="stylesheet">
    
    <style>
        .table-responsive {
            border-radius: 10px;
            overflow: hidden;
            box-shadow: 0 0 20px rgba(0, 0, 0, 0.1);
        }
        
        .table th {
            background-color: #ffa704;
            color: white;
            font-weight: 600;
            border: none;
        }
        
        .table td {
            vertical-align: middle;
        }
        
        .product-img {
            width: 60px;
            height: 60px;
            object-fit: cover;
            border-radius: 5px;
        }
        
        .action-buttons .btn {
            margin-right: 5px;
        }
        
        .page-title {
            color: #db920a;
            font-weight: 700;
            margin-bottom: 20px;
        }
        
        .status-badge {
            padding: 5px 10px;
            border-radius: 20px;
            font-size: 0.8rem;
            font-weight: 600;
        }
        
        .status-active {
            background-color: #d1f7c4;
            color: #2e7d32;
        }
        
        .status-inactive {
            background-color: #ffcdd2;
            color: #cf8b0c;
        }
        
        .add-product-btn {
            margin-bottom: 20px;
        }
        
        .search-box {
            margin-bottom: 20px;
        }

        #mdf{
            text-decoration:none ;
            color: white;
        }
    </style>
</head>

<body>

    <!-- Spinner Start -->
    <div id="spinner"
        class="show bg-white position-fixed translate-middle w-100 vh-100 top-50 start-50 d-flex align-items-center justify-content-center">
        <div class="spinner-border text-primary" style="width: 3rem; height: 3rem;" role="status">
            <span class="sr-only">Loading...</span>
        </div>
    </div>
    <!-- Spinner End -->


    <!-- Topbar Start -->
    <div class="container-fluid px-5 d-none border-bottom d-lg-block">
        <div class="row gx-0 align-items-center">
            <div class="col-lg-4 text-center text-lg-start mb-lg-0">
                <div class="d-inline-flex align-items-center" style="height: 45px;">
                    <a href="#" class="text-muted me-2"> </a><small> / </small>
                    <a href="#" class="text-muted mx-2"> </a><small> / </small>
                    <a href="#" class="text-muted ms-2"> </a>
                </div>
            </div>
            <div class="col-lg-4 text-center d-flex align-items-center justify-content-center">
                <small class="text-dark"></small>
                <a href="#" class="text-muted"></a>
            </div>

            <div class="col-lg-4 text-center text-lg-end">
                <div class="d-inline-flex align-items-center" style="height: 45px;">
                    <div class="dropdown">
                        <a href="#" class="dropdown-toggle text-muted me-2" data-bs-toggle="dropdown"><small>
                                USD</small></a>
                        <div class="dropdown-menu rounded">
                            <a href="#" class="dropdown-item"> Euro</a>
                            <a href="#" class="dropdown-item"> Dolar</a>
                        </div>
                    </div>
                   
                </div>
            </div>
        </div>
    </div>
    <!-- Topbar End -->

    <!-- Navbar & Hero Start -->
    <div class="container-fluid nav-bar p-0">
        <div class="row gx-0 bg-primary px-5 align-items-center">
            <div class="col-lg-3 d-none d-lg-block">
                <nav class="navbar navbar-light position-relative" style="width: 250px;">
                    <button class="navbar-toggler border-0 fs-4 w-100 px-0 text-start" type="button"
                        data-bs-toggle="collapse" data-bs-target="#allCat">
                        <h4 class="m-0"><i class="fa fa-bars me-2"></i>SHOP</h4>
                    </button>
                  
                </nav>
            </div>
            <div class="col-12 col-lg-9">
                <nav class="navbar navbar-expand-lg navbar-light bg-primary ">
                    <a href="" class="navbar-brand d-block d-lg-none">
                        <h1 class="display-5 text-secondary m-0"><i
                                class="fas fa-shopping-bag text-white me-2"></i>Electro</h1>
                    </a>
                    <button class="navbar-toggler ms-auto" type="button" data-bs-toggle="collapse"
                        data-bs-target="#navbarCollapse">
                        <span class="fa fa-bars fa-1x"></span>
                    </button>
                    <div class="collapse navbar-collapse" id="navbarCollapse">
                        <div class="navbar-nav ms-auto py-0">
                        <a href="sessionadmin.php" class="nav-item nav-link">Acceuil</a>
                            <a href="listecat.php" class="nav-item nav-link">Catégorie</a>
                            <a href="listeprod.php" class="nav-item nav-link">Produit</a>
                            <a href="listeclient.php" class="nav-item nav-link">Client</a>
                            <a href="listecommande.php" class="nav-item nav-link">Commande</a>
                            <div class="nav-item dropdown d-block d-lg-none mb-3">
                                <a href="#" class="nav-link dropdown-toggle" data-bs-toggle="dropdown">Toutes les Catégories</a>
                              
                            </div>
                        </div>
                        <a href=""></a>
                    </div>
                </nav>
            </div>
        </div>
    </div>
    <!-- Navbar & Hero End -->

    <!-- Page Header Start -->
    
     <div class="container-fluid page-header py-5">
        <h1 class="text-center text-white display-6 wow fadeInUp" data-wow-delay="0.1s">Gestion des Catégories</h1>
        <ol class="breadcrumb justify-content-center mb-0 wow fadeInUp" data-wow-delay="0.3s">
            <li class="breadcrumb-item"><a href="#">Accueil</a></li>

            <li class="breadcrumb-item active text-white">Gestion des Catégories</li>
        </ol>
    </div>
    <!-- Page Header End -->

    <!-- Products Management Section Start -->
    <div class="container-fluid py-5">
        <div class="container">
            <div class="row">
                <div class="col-12">
                    <div class="d-flex justify-content-between align-items-center mb-4">
                        <div class="search-box">
                            <div class="input-group">
                                <input type="text" class="form-control rounded-pill" placeholder="Rechercher une catégorie...">
                                <button class="btn btn-primary rounded-pill ms-2" type="button">
                                    <i class="fas fa-search"></i>
                                </button>
                            </div>
                        </div>
                    
                        <div>
                            <a href="addcategorie.php" style="background-color: #cf8b0c; padding: 10px 15px; border-radius: 5px; color: white;"> <i class="fas fa-plus me-2"></i>Ajouter une catégorie</a>
                        </div>
                    </div>
                    
                    <div class="table-responsive">
                        <table class="table table-striped table-hover">
                            <thead>
                                <tr>
                                    <th scope="col">ID</th>
                                    <th scope="col">Catégorie</th>                                    
                                    <th scope="col">Actions</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($recup as $cat ) { ?>
                                <tr>
                                    <th scope="row"><?= $cat['codecat'] ?></th>                                    
                                    <td><?= $cat['libelle'] ?></td>                                    
                                    <td class="action-buttons">
                                        <button class="btn btn-sm btn-primary">
                                            <i class="fas fa-edit"></i> <a href="updatecategorie.php?id=<?= $cat['codecat'] ?>" id="mdf">Modifier</a>
                                        </button>
                                        <button class="btn btn-sm btn-danger">
                                            <i class="fas fa-trash"></i> <a href="deletecategorie.php?id=<?= $cat['codecat'] ?>" id="mdf" onclick="return confirm('Êtes-vous sûr de vouloir supprimer cette catégorie ?')">Supprimer</a>
                                        </button>
                                    </td>
                                </tr>  
                                <?php } ?>                            
                            </tbody>
                        </table>
                    </div>
                    
                   
                </div>
            </div>
        </div>
    </div>
    <!-- Products Management Section End -->

    <!-- Footer Start -->
    <div class="container-fluid footer py-5 wow fadeIn" data-wow-delay="0.2s">
        <div class="container py-5">
            <div class="row g-5">
                <div class="col-md-6 col-lg-6 col-xl-3">
                    <div class="footer-item d-flex flex-column">
                        <div class="footer-item">
                            <h4 class="text-primary mb-4">Newsletter</h4>
                            <p class="mb-3">Dolor amet sit justo amet elitr clita ipsum elitr est.Lorem ipsum dolor sit
                                amet, consectetur adipiscing elit consectetur adipiscing elit.</p>
                            <div class="position-relative mx-auto rounded-pill">
                                <input class="form-control rounded-pill w-100 py-3 ps-4 pe-5" type="text"
                                    placeholder="Entrez votre email">
                                <button type="button"
                                    class="btn btn-primary rounded-pill position-absolute top-0 end-0 py-2 mt-2 me-2">S'inscrire</button>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-md-6 col-lg-6 col-xl-3">
                    <div class="footer-item d-flex flex-column">
                        <h4 class="text-primary mb-4">Service Client</h4>
                        <a href="#" class=""><i class="fas fa-angle-right me-2"></i> Contactez-nous</a>
                        <a href="#" class=""><i class="fas fa-angle-right me-2"></i> Retours</a>
                        <a href="#" class=""><i class="fas fa-angle-right me-2"></i> Historique des Commandes</a>
                        <a href="#" class=""><i class="fas fa-angle-right me-2"></i> Plan du Site</a>
                        <a href="#" class=""><i class="fas fa-angle-right me-2"></i> Témoignages</a>
                        <a href="#" class=""><i class="fas fa-angle-right me-2"></i> Mon Compte</a>
                        <a href="#" class=""><i class="fas fa-angle-right me-2"></i> Désinscription aux Notifications</a>
                    </div>
                </div>
                <div class="col-md-6 col-lg-6 col-xl-3">
                    <div class="footer-item d-flex flex-column">
                        <h4 class="text-primary mb-4">Informations</h4>
                        <a href="#" class=""><i class="fas fa-angle-right me-2"></i> À propos de nous</a>
                        <a href="#" class=""><i class="fas fa-angle-right me-2"></i> Informations de livraison</a>
                        <a href="#" class=""><i class="fas fa-angle-right me-2"></i> Politique de confidentialité</a>
                        <a href="#" class=""><i class="fas fa-angle-right me-2"></i> Conditions générales</a>
                        <a href="#" class=""><i class="fas fa-angle-right me-2"></i> Garantie</a>
                        <a href="#" class=""><i class="fas fa-angle-right me-2"></i> FAQ</a>
                        <a href="#" class=""><i class="fas fa-angle-right me-2"></i> Connexion Vendeur</a>
                    </div>
                </div>
                <div class="col-md-6 col-lg-6 col-xl-3">
                    <div class="footer-item d-flex flex-column">
                        <h4 class="text-primary mb-4">Extras</h4>
                        <a href="#" class=""><i class="fas fa-angle-right me-2"></i> Marques</a>
                        <a href="#" class=""><i class="fas fa-angle-right me-2"></i> Chèques-cadeaux</a>
                        <a href="#" class=""><i class="fas fa-angle-right me-2"></i> Affiliés</a>
                        <a href="#" class=""><i class="fas fa-angle-right me-2"></i> Liste de souhaits</a>
                        <a href="#" class=""><i class="fas fa-angle-right me-2"></i> Historique des Commandes</a>
                        <a href="#" class=""><i class="fas fa-angle-right me-2"></i> Suivre votre Commande</a>
                        <a href="#" class=""><i class="fas fa-angle-right me-2"></i> Suivre votre Commande</a>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- Footer End -->

    <!-- Copyright Start -->
  
    <!-- Copyright End -->

    <!-- Back to Top -->
    <a href="#" class="btn btn-primary btn-lg-square back-to-top"><i class="fa fa-arrow-up"></i></a>

    <!-- JavaScript Libraries -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.4/jquery.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0/dist/js/bootstrap.bundle.min.js"></script>
    <script src="lib/wow/wow.min.js"></script>
    <script src="lib/owlcarousel/owl.carousel.min.js"></script>

    <!-- Template Javascript -->
    <script src="js/main.js"></script>
    

</body>

</html>