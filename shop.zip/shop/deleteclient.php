<?php
include("connect.php");

if(isset($_GET['id'])){
    $id = $_GET['id'];
    
    $sql_check = $bdd->prepare("SELECT COUNT(*) as count FROM commande WHERE idcli = ?");
    $sql_check->execute([$id]);
    $result = $sql_check->fetch();
    
    if($result['count'] > 0){
        echo "<script>alert('Impossible de supprimer ce client car il a des commandes')</script>";
        header("refresh: 0.5 url=listeclient.php");
    }else{
        $sql_delete_user = $bdd->prepare("DELETE FROM utilisateur WHERE idcli = ?");
        $sql_delete_user->execute([$id]);
        
        $sql = $bdd->prepare("DELETE FROM client WHERE idcli = ?");
        $exe = $sql->execute([$id]);
        
        if($exe){
            echo "<script>alert('Client supprimé avec succès')</script>";
            header("refresh: 0.5 url=listeclient.php");
        }else{
            echo "<script>alert('Erreur lors de la suppression')</script>";
            header("refresh: 0.5 url=listeclient.php");
        }
    }
}else{
    header("refresh: 0.5 url=listeclient.php");
}
?>