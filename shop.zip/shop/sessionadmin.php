<?php
include("connect.php");

$sql_produits = "SELECT COUNT(*) as total FROM produit";
$exe_produits = $bdd->query($sql_produits);
$total_produits = $exe_produits->fetch()['total'];

$sql_clients = "SELECT COUNT(*) as total FROM client";
$exe_clients = $bdd->query($sql_clients);
$total_clients = $exe_clients->fetch()['total'];

$sql_commandes = "SELECT COUNT(*) as total FROM commande";
$exe_commandes = $bdd->query($sql_commandes);
$total_commandes = $exe_commandes->fetch()['total'];

$sql_categories = "SELECT COUNT(*) as total FROM categorie";
$exe_categories = $bdd->query($sql_categories);
$total_categories = $exe_categories->fetch()['total'];

$sql_ventes = "SELECT SUM(montant) as total FROM commande WHERE etat = 'Livrée'";
$exe_ventes = $bdd->query($sql_ventes);
$total_ventes = $exe_ventes->fetch()['total'] ?? 0;

$sql_commandes_recentes = "SELECT c.*, cl.nom, cl.prenom FROM commande c 
                          JOIN client cl ON c.idcli = cl.idcli 
                          ORDER BY c.datecmd DESC LIMIT 5";
$exe_commandes_recentes = $bdd->query($sql_commandes_recentes);
$commandes_recentes = $exe_commandes_recentes->fetchAll();
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="utf-8">
    <title>Electro - Tableau de Bord Admin</title>
    <meta content="width=device-width, initial-scale=1.0" name="viewport">

    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Open+Sans:wght@400;500;600;700&family=Roboto:wght@400;500;700&display=swap" rel="stylesheet">

    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.15.4/css/all.css" />
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.4.1/font/bootstrap-icons.css" rel="stylesheet">

    <link href="lib/animate/animate.min.css" rel="stylesheet">
    <link href="lib/owlcarousel/assets/owl.carousel.min.css" rel="stylesheet">

    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="css/style.css" rel="stylesheet">
    
    <style>
        .stat-card {
            background: white;
            border-radius: 10px;
            padding: 25px;
            box-shadow: 0 4px 12px rgba(0, 0, 0, 0.08);
            transition: transform 0.3s ease;
            height: 100%;
        }
        
        .stat-card:hover {
            transform: translateY(-5px);
            box-shadow: 0 6px 18px rgba(0, 0, 0, 0.12);
        }
        
        .stat-icon {
            width: 60px;
            height: 60px;
            border-radius: 10px;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 24px;
            margin-bottom: 15px;
        }
        
        .stat-number {
            font-size: 2rem;
            font-weight: 700;
            color: #333;
            margin-bottom: 5px;
        }
        
        .stat-title {
            color: #666;
            font-size: 0.9rem;
            text-transform: uppercase;
            letter-spacing: 1px;
        }
        
        .card-primary { border-left: 4px solid #007bff; }
        .card-success { border-left: 4px solid #28a745; }
        .card-warning { border-left: 4px solid #ffc107; }
        .card-danger { border-left: 4px solid #dc3545; }
        .card-info { border-left: 4px solid #17a2b8; }
        .card-dark { border-left: 4px solid #343a40; }
        
        .icon-primary { background-color: rgba(0, 123, 255, 0.1); color: #007bff; }
        .icon-success { background-color: rgba(40, 167, 69, 0.1); color: #28a745; }
        .icon-warning { background-color: rgba(255, 193, 7, 0.1); color: #ffc107; }
        .icon-danger { background-color: rgba(220, 53, 69, 0.1); color: #dc3545; }
        .icon-info { background-color: rgba(23, 162, 184, 0.1); color: #17a2b8; }
        .icon-dark { background-color: rgba(52, 58, 64, 0.1); color: #343a40; }
        
        .table-responsive {
            border-radius: 10px;
            overflow: hidden;
            box-shadow: 0 0 20px rgba(0, 0, 0, 0.1);
        }
        
        .table th {
            background-color: #ffa704;
            color: white;
            font-weight: 600;
            border: none;
        }
        
        .quick-actions {
            background: white;
            border-radius: 10px;
            padding: 25px;
            box-shadow: 0 4px 12px rgba(0, 0, 0, 0.08);
            height: 100%;
        }
        
        .quick-action-item {
            display: flex;
            align-items: center;
            padding: 12px 15px;
            margin-bottom: 10px;
            background-color: #f8f9fa;
            border-radius: 8px;
            transition: all 0.3s ease;
            text-decoration: none;
            color: #333;
        }
        
        .quick-action-item:hover {
            background-color: #e9ecef;
            transform: translateX(5px);
            text-decoration: none;
            color: #333;
        }
        
        .quick-action-icon {
            width: 40px;
            height: 40px;
            border-radius: 8px;
            display: flex;
            align-items: center;
            justify-content: center;
            margin-right: 15px;
            color: white;
        }
        
        .quick-action-text {
            flex-grow: 1;
        }
        
        .welcome-card {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            border-radius: 10px;
            padding: 30px;
            margin-bottom: 30px;
            box-shadow: 0 6px 20px rgba(102, 126, 234, 0.3);
        }
        
        .welcome-title {
            font-size: 1.8rem;
            font-weight: 700;
            margin-bottom: 10px;
        }
        
        .welcome-text {
            opacity: 0.9;
            font-size: 1rem;
        }
        
        .section-title {
            color: #333;
            font-weight: 600;
            margin-bottom: 20px;
            padding-bottom: 10px;
            border-bottom: 2px solid #f0f0f0;
        }
        
        .etat-badge {
            padding: 5px 10px;
            border-radius: 20px;
            font-size: 0.8rem;
            font-weight: 600;
        }
        
        .etat-en-cours {
            background-color: #fff3cd;
            color: #856404;
        }
        
        .etat-livree {
            background-color: #d1f7c4;
            color: #2e7d32;
        }
        
        .etat-annulee {
            background-color: #ffcdd2;
            color: #c62828;
        }
    </style>
</head>

<body>
    <div id="spinner" class="show bg-white position-fixed translate-middle w-100 vh-100 top-50 start-50 d-flex align-items-center justify-content-center">
        <div class="spinner-border text-primary" style="width: 3rem; height: 3rem;" role="status">
            <span class="sr-only">Loading...</span>
        </div>
    </div>

    <div class="container-fluid px-5 d-none border-bottom d-lg-block">
        <div class="row gx-0 align-items-center">
            <div class="col-lg-4 text-center text-lg-start mb-lg-0">
                <div class="d-inline-flex align-items-center" style="height: 45px;">
                    <a href="#" class="text-muted me-2"></a><small>  </small>
                    <a href="#" class="text-muted mx-2"></a><small> </small>
                    <a href="#" class="text-muted ms-2"></a>
                </div>
            </div>
            <div class="col-lg-4 text-center d-flex align-items-center justify-content-center">
                <small class="text-dark"></small>
                <a href="#" class="text-muted"></a>
            </div>
            <div class="col-lg-4 text-center text-lg-end">
                <div class="d-inline-flex align-items-center" style="height: 45px;">
                    <a href="#" class="text-muted"></a>
                </div>
            </div>
        </div>
    </div>

    <div class="container-fluid nav-bar p-0">
        <div class="row gx-0 bg-primary px-5 align-items-center">
            <div class="col-12">
                <nav class="navbar navbar-expand-lg navbar-light bg-primary">
                    <a href="#" class="navbar-brand d-block d-lg-none">
                        <h1 class="display-5 text-secondary m-0"><i class="fas fa-shopping-bag text-white me-2"></i>Electro</h1>
                    </a>
                    <button class="navbar-toggler ms-auto" type="button" data-bs-toggle="collapse" data-bs-target="#navbarCollapse">
                        <span class="fa fa-bars fa-1x"></span>
                    </button>
                    <div class="collapse navbar-collapse" id="navbarCollapse">
                        <div class="navbar-nav ms-auto py-0">
                            <a href="sessionadmin.php" class="nav-item nav-link active">Acceuil</a>
                            <a href="listecat.php" class="nav-item nav-link">Catégorie</a>
                            <a href="listeprod.php" class="nav-item nav-link">Produit</a>
                            <a href="listeclient.php" class="nav-item nav-link">Client</a>
                            <a href="listecommande.php" class="nav-item nav-link">Commande</a>
                        </div>
                        <a href="#"></a>
                    </div>
                </nav>
            </div>
        </div>
    </div>

    <div class="container-fluid page-header py-5">
        <h1 class="text-center text-white display-6 wow fadeInUp" data-wow-delay="0.1s">Tableau de Bord Administrateur</h1>
    </div>

    <div class="container-fluid contact py-5">
        <div class="container py-5">
            <div class="welcome-card">
                <div class="row align-items-center">
                    <div class="col-md-8">
                        <h2 class="welcome-title">Bienvenue, Administrateur</h2>
                        <p class="welcome-text">Gérez efficacement votre boutique Electro. Consultez les statistiques, gérez les produits, les clients et les commandes.</p>
                    </div>
                    <div class="col-md-4 text-center">
                        <i class="fas fa-chart-line fa-4x opacity-75"></i>
                    </div>
                </div>
            </div>
            
            <div class="row g-4 mb-5">
                <div class="col-md-6 col-lg-3">
                    <div class="stat-card card-primary">
                        <div class="stat-icon icon-primary">
                            <i class="fas fa-box"></i>
                        </div>
                        <div class="stat-number"><?= $total_produits ?></div>
                        <div class="stat-title">Produits</div>
                    </div>
                </div>
                
                <div class="col-md-6 col-lg-3">
                    <div class="stat-card card-success">
                        <div class="stat-icon icon-success">
                            <i class="fas fa-users"></i>
                        </div>
                        <div class="stat-number"><?= $total_clients ?></div>
                        <div class="stat-title">Clients</div>
                    </div>
                </div>
                
                <div class="col-md-6 col-lg-3">
                    <div class="stat-card card-warning">
                        <div class="stat-icon icon-warning">
                            <i class="fas fa-shopping-cart"></i>
                        </div>
                        <div class="stat-number"><?= $total_commandes ?></div>
                        <div class="stat-title">Commandes</div>
                    </div>
                </div>
                
                <div class="col-md-6 col-lg-3">
                    <div class="stat-card card-danger">
                        <div class="stat-icon icon-danger">
                            <i class="fas fa-money-bill-wave"></i>
                        </div>
                        <div class="stat-number"><?= number_format($total_ventes, 0, ',', ' ') ?> FCFA</div>
                        <div class="stat-title">Chiffre d'Affaires</div>
                    </div>
                </div>
            </div>
            
            <div class="row g-4">
                <div class="col-lg-8">
                    <div class="bg-light rounded p-4">
                        <h4 class="section-title">Commandes Récentes</h4>
                        <div class="table-responsive">
                            <table class="table table-striped table-hover">
                                <thead>
                                    <tr>
                                        <th scope="col">ID</th>
                                        <th scope="col">Date</th>
                                        <th scope="col">Client</th>
                                        <th scope="col">Montant</th>
                                        <th scope="col">État</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php if(count($commandes_recentes) > 0): ?>
                                        <?php foreach($commandes_recentes as $cmd): 
                                            $etatClass = '';
                                            if($cmd['etat'] == 'En cours') $etatClass = 'etat-en-cours';
                                            elseif($cmd['etat'] == 'Livrée') $etatClass = 'etat-livree';
                                            elseif($cmd['etat'] == 'Annulée') $etatClass = 'etat-annulee';
                                        ?>
                                        <tr>
                                            <th scope="row"><?= $cmd['idcmd'] ?></th>
                                            <td><?= $cmd['datecmd'] ?></td>
                                            <td><?= $cmd['nom'] ?> <?= $cmd['prenom'] ?></td>
                                            <td><?= number_format($cmd['montant'], 0, ',', ' ') ?> FCFA</td>
                                            <td>
                                                <span class="etat-badge <?= $etatClass ?>">
                                                    <?= $cmd['etat'] ?>
                                                </span>
                                            </td>
                                        </tr>
                                        <?php endforeach; ?>
                                    <?php else: ?>
                                        <tr>
                                            <td colspan="5" class="text-center text-muted">Aucune commande récente</td>
                                        </tr>
                                    <?php endif; ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
                
                <div class="col-lg-4">
                    <div class="quick-actions">
                        <h4 class="section-title">Actions Rapides</h4>
                        <a href="addproduit.php" class="quick-action-item">
                            <div class="quick-action-icon" style="background-color: #007bff;">
                                <i class="fas fa-plus"></i>
                            </div>
                            <div class="quick-action-text">
                                <strong>Ajouter un produit</strong>
                                <small class="text-muted d-block">Nouvel article en stock</small>
                            </div>
                            <i class="fas fa-chevron-right text-muted"></i>
                        </a>
                        
                        <a href="addcommande.php" class="quick-action-item">
                            <div class="quick-action-icon" style="background-color: #28a745;">
                                <i class="fas fa-shopping-cart"></i>
                            </div>
                            <div class="quick-action-text">
                                <strong>Nouvelle commande</strong>
                                <small class="text-muted d-block">Créer une commande</small>
                            </div>
                            <i class="fas fa-chevron-right text-muted"></i>
                        </a>
                        
                        <a href="addclient.php" class="quick-action-item">
                            <div class="quick-action-icon" style="background-color: #ffc107;">
                                <i class="fas fa-user-plus"></i>
                            </div>
                            <div class="quick-action-text">
                                <strong>Ajouter un client</strong>
                                <small class="text-muted d-block">Nouveau client</small>
                            </div>
                            <i class="fas fa-chevron-right text-muted"></i>
                        </a>
                        
                        <a href="addcategorie.php" class="quick-action-item">
                            <div class="quick-action-icon" style="background-color: #17a2b8;">
                                <i class="fas fa-tags"></i>
                            </div>
                            <div class="quick-action-text">
                                <strong>Nouvelle catégorie</strong>
                                <small class="text-muted d-block">Ajouter une catégorie</small>
                            </div>
                            <i class="fas fa-chevron-right text-muted"></i>
                        </a>
                        
                        <a href="listeprod.php" class="quick-action-item">
                            <div class="quick-action-icon" style="background-color: #6f42c1;">
                                <i class="fas fa-boxes"></i>
                            </div>
                            <div class="quick-action-text">
                                <strong>Voir tous les produits</strong>
                                <small class="text-muted d-block">Gestion du stock</small>
                            </div>
                            <i class="fas fa-chevron-right text-muted"></i>
                        </a>
                        
                        <a href="listecommande.php" class="quick-action-item">
                            <div class="quick-action-icon" style="background-color: #fd7e14;">
                                <i class="fas fa-clipboard-list"></i>
                            </div>
                            <div class="quick-action-text">
                                <strong>Voir toutes les commandes</strong>
                                <small class="text-muted d-block">Suivi des ventes</small>
                            </div>
                            <i class="fas fa-chevron-right text-muted"></i>
                        </a>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="container-fluid footer py-5 wow fadeIn" data-wow-delay="0.2s">
        <div class="container py-5">
            <div class="row g-5">
                <div class="col-md-6 col-lg-6 col-xl-3">
                    <div class="footer-item d-flex flex-column">
                        <div class="footer-item">
                            <h4 class="text-primary mb-4">Newsletter</h4>
                            <p class="mb-3">Dolor amet sit justo amet elitr clita ipsum elitr est.Lorem ipsum dolor sit amet, consectetur adipiscing elit consectetur adipiscing elit.</p>
                            <div class="position-relative mx-auto rounded-pill">
                                <input class="form-control rounded-pill w-100 py-3 ps-4 pe-5" type="text" placeholder="Enter your email">
                                <button type="button" class="btn btn-primary rounded-pill position-absolute top-0 end-0 py-2 mt-2 me-2">SignUp</button>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-md-6 col-lg-6 col-xl-3">
                    <div class="footer-item d-flex flex-column">
                        <h4 class="text-primary mb-4">Customer Service</h4>
                        <a href="#" class=""><i class="fas fa-angle-right me-2"></i> Contact Us</a>
                        <a href="#" class=""><i class="fas fa-angle-right me-2"></i> Returns</a>
                        <a href="#" class=""><i class="fas fa-angle-right me-2"></i> Order History</a>
                        <a href="#" class=""><i class="fas fa-angle-right me-2"></i> Site Map</a>
                        <a href="#" class=""><i class="fas fa-angle-right me-2"></i> Testimonials</a>
                        <a href="#" class=""><i class="fas fa-angle-right me-2"></i> My Account</a>
                        <a href="#" class=""><i class="fas fa-angle-right me-2"></i> Unsubscribe Notification</a>
                    </div>
                </div>
                <div class="col-md-6 col-lg-6 col-xl-3">
                    <div class="footer-item d-flex flex-column">
                        <h4 class="text-primary mb-4">Information</h4>
                        <a href="#" class=""><i class="fas fa-angle-right me-2"></i> About Us</a>
                        <a href="#" class=""><i class="fas fa-angle-right me-2"></i> Delivery infomation</a>
                        <a href="#" class=""><i class="fas fa-angle-right me-2"></i> Privacy Policy</a>
                        <a href="#" class=""><i class="fas fa-angle-right me-2"></i> Terms & Conditions</a>
                        <a href="#" class=""><i class="fas fa-angle-right me-2"></i> Warranty</a>
                        <a href="#" class=""><i class="fas fa-angle-right me-2"></i> FAQ</a>
                        <a href="#" class=""><i class="fas fa-angle-right me-2"></i> Seller Login</a>
                    </div>
                </div>
                <div class="col-md-6 col-lg-6 col-xl-3">
                    <div class="footer-item d-flex flex-column">
                        <h4 class="text-primary mb-4">Extras</h4>
                        <a href="#" class=""><i class="fas fa-angle-right me-2"></i> Brands</a>
                        <a href="#" class=""><i class="fas fa-angle-right me-2"></i> Gift Vouchers</a>
                        <a href="#" class=""><i class="fas fa-angle-right me-2"></i> Affiliates</a>
                        <a href="#" class=""><i class="fas fa-angle-right me-2"></i> Wishlist</a>
                        <a href="#" class=""><i class="fas fa-angle-right me-2"></i> Order History</a>
                        <a href="#" class=""><i class="fas fa-angle-right me-2"></i> Track Your Order</a>
                        <a href="#" class=""><i class="fas fa-angle-right me-2"></i> Track Your Order</a>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <a href="#" class="btn btn-primary btn-lg-square back-to-top"><i class="fa fa-arrow-up"></i></a>

    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.4/jquery.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0/dist/js/bootstrap.bundle.min.js"></script>
    <script src="lib/wow/wow.min.js"></script>
    <script src="lib/owlcarousel/owl.carousel.min.js"></script>
    <script src="js/main.js"></script>
</body>
</html>