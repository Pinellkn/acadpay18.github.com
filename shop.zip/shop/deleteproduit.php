<?php
include("connect.php");

if(isset($_GET['id'])){
    $id = $_GET['id'];
    
    $sql = $bdd->prepare("DELETE FROM produit WHERE idprod = ?");
    $exe = $sql->execute([$id]);
    
    if($exe){
        echo "<script>alert('Produit supprimé avec succès')</script>";
        header("refresh: 0.5 url=listeprod.php");
    }else{
        echo "<script>alert('Erreur lors de la suppression')</script>";
        header("refresh: 0.5 url=listeprod.php");
    }
}else{
    header("refresh: 0.5 url=listeprod.php");
}
?>