<?php
    try {
        $bdd = new PDO("mysql:host=localhost;dbname=db_commandes","root","");
        //echo "succes";
    }catch(PDOException $e){
        die($e->getMessage());
       // echo "echec0";
    }
?>