<?php
include("connect.php");

if(isset($_GET['id'])){
    $id = $_GET['id'];
    
    try {
        $bdd->beginTransaction();
        
        $sql_delete_lignes = $bdd->prepare("DELETE FROM ligne_commande WHERE idcmd = ?");
        $sql_delete_lignes->execute([$id]);
        
        $sql = $bdd->prepare("DELETE FROM commande WHERE idcmd = ?");
        $exe = $sql->execute([$id]);
        
        $bdd->commit();
        
        if($exe){
            echo "<script>alert('Commande supprimée avec succès')</script>";
            header("refresh: 0.5 url=listecommande.php");
        }else{
            echo "<script>alert('Erreur lors de la suppression')</script>";
            header("refresh: 0.5 url=listecommande.php");
        }
    } catch(Exception $e) {
        $bdd->rollBack();
        echo "<script>alert('Erreur lors de la suppression')</script>";
        header("refresh: 0.5 url=listecommande.php");
    }
}else{
    header("refresh: 0.5 url=listecommande.php");
}
?>