-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Hôte : 127.0.0.1
-- Généré le : ven. 19 déc. 2025 à 11:07
-- Version du serveur : 10.4.28-MariaDB
-- Version de PHP : 8.2.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de données : `db_commandes`
--

-- --------------------------------------------------------

--
-- Structure de la table `categorie`
--

CREATE TABLE `categorie` (
  `codecat` int(11) NOT NULL,
  `libelle` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Déchargement des données de la table `categorie`
--

INSERT INTO `categorie` (`codecat`, `libelle`) VALUES
(1, 'Electroniques'),
(2, 'Electroménager'),
(3, 'Alimentaire'),
(4, 'Entretien');

-- --------------------------------------------------------

--
-- Structure de la table `client`
--

CREATE TABLE `client` (
  `idcli` int(11) NOT NULL,
  `nom` varchar(20) NOT NULL,
  `prenom` varchar(20) NOT NULL,
  `tel` varchar(10) NOT NULL,
  `adresse` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Déchargement des données de la table `client`
--

INSERT INTO `client` (`idcli`, `nom`, `prenom`, `tel`, `adresse`) VALUES
(1, 'admin', 'admin', '43152723', 'Parana');

-- --------------------------------------------------------

--
-- Structure de la table `commande`
--

CREATE TABLE `commande` (
  `idcmd` int(11) NOT NULL,
  `datecmd` date NOT NULL,
  `etat` varchar(10) NOT NULL,
  `montant` int(11) NOT NULL,
  `idcli` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Déchargement des données de la table `commande`
--

INSERT INTO `commande` (`idcmd`, `datecmd`, `etat`, `montant`, `idcli`) VALUES
(2, '2025-12-19', 'En cours', 360000, 1);

-- --------------------------------------------------------

--
-- Structure de la table `ligne_commande`
--

CREATE TABLE `ligne_commande` (
  `idligne` int(11) NOT NULL,
  `idcmd` int(11) NOT NULL,
  `idprod` int(11) NOT NULL,
  `quantite` int(11) NOT NULL,
  `prix_unitaire` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Déchargement des données de la table `ligne_commande`
--

INSERT INTO `ligne_commande` (`idligne`, `idcmd`, `idprod`, `quantite`, `prix_unitaire`) VALUES
(1, 2, 10, 4, 90000);

-- --------------------------------------------------------

--
-- Structure de la table `produit`
--

CREATE TABLE `produit` (
  `idprod` int(11) NOT NULL,
  `designation` varchar(30) NOT NULL,
  `prix` int(11) NOT NULL,
  `stock` int(11) NOT NULL,
  `description` varchar(100) DEFAULT NULL,
  `photo` varchar(30) DEFAULT NULL,
  `codecat` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Déchargement des données de la table `produit`
--

INSERT INTO `produit` (`idprod`, `designation`, `prix`, `stock`, `description`, `photo`, `codecat`) VALUES
(1, 'Montre', 20000, 9, 'Montre éléctronique', 'photos/product-2.png', 1),
(2, 'Appareil photo', 12000, 10, 'Un appareil photo éléctronique\r\n', 'photos/php71DF.tmp', 1),
(3, 'Smartphone', 85000, 200, 'smartphone électronique à prix bas', 'photos/php8B61.tmp', 1),
(4, 'Casque', 1800, 80, 'Casque électroménager', 'photos/php6C4.tmp', 2),
(5, 'Ordinateur Portable', 380000, 120, 'PC', 'photos/phpFC7B.tmp', 1),
(6, 'Drone', 150000, 75, 'Drone éléctronique', 'photos/php231A.tmp', 1),
(7, 'Multimètre', 15000, 10, 'Ampèremètre et voltmètre', 'photos/php53FA.tmp', 4),
(8, 'Ventilateur', 30000, 20, 'Ventilateur ', 'photos/phpBDC.tmp', 2),
(9, 'Machine à laver', 50000, 50, 'machine à laver', 'photos/phpD5F3.tmp', 1),
(10, 'Lave vaisselle', 90000, 60, 'lave vaisselle', 'photos/phpBE51.tmp', 2),
(11, 'Baffe', 8000, 70, 'baffe de maison', 'photos/phpD7E0.tmp', 2),
(12, 'Microondes', 40000, 60, 'microondes', 'photos/phpD344.tmp', 2),
(13, 'Télévision', 100000, 85, 'Télé', 'photos/phpAE62.tmp', 2),
(14, 'Climatiseur', 60000, 15, 'Climatiseur de bureau et de maison\r\n', 'photos/climatideur1.jpg', 1),
(15, 'Aspirateur', 25000, 65, 'Pour vos nettoyages et entretien', 'photos/php99B5.tmp', 4);

-- --------------------------------------------------------

--
-- Structure de la table `utilisateur`
--

CREATE TABLE `utilisateur` (
  `iduser` int(11) NOT NULL,
  `email` varchar(30) NOT NULL,
  `profil` varchar(10) NOT NULL,
  `mdp` varchar(12) NOT NULL,
  `idcli` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Déchargement des données de la table `utilisateur`
--

INSERT INTO `utilisateur` (`iduser`, `email`, `profil`, `mdp`, `idcli`) VALUES
(2, 'admin@gmail.com', 'ADMIN', 'admin', 1);

--
-- Index pour les tables déchargées
--

--
-- Index pour la table `categorie`
--
ALTER TABLE `categorie`
  ADD PRIMARY KEY (`codecat`);

--
-- Index pour la table `client`
--
ALTER TABLE `client`
  ADD PRIMARY KEY (`idcli`);

--
-- Index pour la table `commande`
--
ALTER TABLE `commande`
  ADD PRIMARY KEY (`idcmd`),
  ADD KEY `idcli` (`idcli`);

--
-- Index pour la table `ligne_commande`
--
ALTER TABLE `ligne_commande`
  ADD PRIMARY KEY (`idligne`),
  ADD KEY `idcmd` (`idcmd`),
  ADD KEY `idprod` (`idprod`);

--
-- Index pour la table `produit`
--
ALTER TABLE `produit`
  ADD PRIMARY KEY (`idprod`),
  ADD KEY `codecat` (`codecat`);

--
-- Index pour la table `utilisateur`
--
ALTER TABLE `utilisateur`
  ADD PRIMARY KEY (`iduser`),
  ADD KEY `idcli` (`idcli`);

--
-- AUTO_INCREMENT pour les tables déchargées
--

--
-- AUTO_INCREMENT pour la table `categorie`
--
ALTER TABLE `categorie`
  MODIFY `codecat` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT pour la table `client`
--
ALTER TABLE `client`
  MODIFY `idcli` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT pour la table `commande`
--
ALTER TABLE `commande`
  MODIFY `idcmd` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT pour la table `ligne_commande`
--
ALTER TABLE `ligne_commande`
  MODIFY `idligne` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT pour la table `produit`
--
ALTER TABLE `produit`
  MODIFY `idprod` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;

--
-- AUTO_INCREMENT pour la table `utilisateur`
--
ALTER TABLE `utilisateur`
  MODIFY `iduser` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- Contraintes pour les tables déchargées
--

--
-- Contraintes pour la table `commande`
--
ALTER TABLE `commande`
  ADD CONSTRAINT `commande_ibfk_1` FOREIGN KEY (`idcli`) REFERENCES `client` (`idcli`);

--
-- Contraintes pour la table `ligne_commande`
--
ALTER TABLE `ligne_commande`
  ADD CONSTRAINT `ligne_commande_ibfk_1` FOREIGN KEY (`idcmd`) REFERENCES `commande` (`idcmd`),
  ADD CONSTRAINT `ligne_commande_ibfk_2` FOREIGN KEY (`idprod`) REFERENCES `produit` (`idprod`);

--
-- Contraintes pour la table `produit`
--
ALTER TABLE `produit`
  ADD CONSTRAINT `produit_ibfk_1` FOREIGN KEY (`codecat`) REFERENCES `categorie` (`codecat`);

--
-- Contraintes pour la table `utilisateur`
--
ALTER TABLE `utilisateur`
  ADD CONSTRAINT `utilisateur_ibfk_1` FOREIGN KEY (`idcli`) REFERENCES `client` (`idcli`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
